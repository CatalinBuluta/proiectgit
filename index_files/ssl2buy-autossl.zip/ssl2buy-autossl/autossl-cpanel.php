<?php
	$pin = isset($_GET['lkey']) ? trim($_GET['lkey']) : '';
	$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
	
	//echo '<pre>'; print_r($ValidateLicenseKeyResponse); die();
	$errorMSG = '';
	
	$isReissue = 0;
	$tempCertificateId = '';

	$pinData = getPinDetailFromLocalStorage($pin);

	if($ValidateLicenseKeyResponse['StatusCode'] != 0){
		$errorMSG = $ValidateLicenseKeyResponse['ErrorDetail']['ErrorMessage'];	
	}else{
		if(empty($pinData)){
			if( strtolower($ValidateLicenseKeyResponse['CertificateStatus']) != '' && strtolower($ValidateLicenseKeyResponse['CertificateStatus']) != 'completed'){
				$errorMSG = 'You have to configure this key on another tool, so please complete this process on that tool.';	
				$ValidateLicenseKeyResponse['StatusCode'] = -1;
			}
		}
	}


?>
<div class="wrap">
	<h1 class="wp-ssl-logo"><img src="<?php echo plugins_url('images/ssl2buy-auto-ssl-logo.svg',__FILE__ ); ?>" alt="SSL2BUY Auto SSL" /></h1>

	<?php if($errorMSG){ ?>
	    <div class="notice notice-error is-dismissible">
	        <p><?php echo $errorMSG; ?></p>
	    </div> 
	<?php } ?>
	
	<?php if($ValidateLicenseKeyResponse['StatusCode'] == 0 && strtolower($ValidateLicenseKeyResponse['PinStatus']) != 'cancelled' ){ 
			$domainListArray = array();
			if(isset($_SESSION['cpanelData'][$pin]) && !empty($_SESSION['cpanelData'][$pin])){
				$domainList = getAllDomainList($_SESSION['cpanelData'][$pin]);
				if(isset($domainList['data']['main_domain']) && !empty($domainList['data']['main_domain'])){
					$dmName = $domainList['data']['main_domain']['domain'];
					$domainListArray[] = ($ValidateLicenseKeyResponse['IsWildcard'] == 1 ) ? '*.'.$dmName : $dmName;

					$_SESSION['cpanelData'][$pin]['rootPath'][$dmName] =  $domainList['data']['main_domain']['documentroot'];
				}

				if(isset($domainList['data']['sub_domains']) && !empty($domainList['data']['sub_domains'])){
					foreach($domainList['data']['sub_domains'] as $subDomainItem){
						$dmName = $subDomainItem['domain'];
						$domainListArray[] = ($ValidateLicenseKeyResponse['IsWildcard'] == 1 ) ? '*.'.$dmName : $dmName;
						$_SESSION['cpanelData'][$pin]['rootPath'][$dmName] =  $subDomainItem['documentroot'];
					}	
				}

				if(isset($domainList['data']['addon_domains']) && !empty($domainList['data']['addon_domains'])){
					foreach($domainList['data']['addon_domains'] as $addonDomainItem){
						$dmName = $addonDomainItem['domain'];
						$domainListArray[] = ($ValidateLicenseKeyResponse['IsWildcard'] == 1 ) ? '*.'.$dmName : $dmName;
						$_SESSION['cpanelData'][$pin]['rootPath'][$dmName] =  $addonDomainItem['documentroot'];
					}	
				}
			}
	?>
		<div class="wp-ssl-main">
			<div class="wp-ssl-left">
				<div class="wp-ssl-steps">
					<ul>
						<li class="step-item complete">
							<span class="wp-ssl-steps-count"><img src="<?php echo plugins_url('images/step-1.svg',__FILE__ ); ?>" alt="License Key" /></span>
							<span class="wp-ssl-steps-name">License Key</span>
						</li>
						<li class="step-item <?php if(!empty($domainListArray)) { ?>complete<?php } else { ?>active<?php } ?>">
							<span class="wp-ssl-steps-count"><img src="<?php echo plugins_url('images/step-2.svg',__FILE__ ); ?>" alt="cPanel Login" /></span>
							<span class="wp-ssl-steps-name">cPanel Login</span>
						</li>
						<li class="step-item <?php if(!empty($domainListArray)) { ?>active<?php } ?>">
							<span class="wp-ssl-steps-count"><img src="<?php echo plugins_url('images/step-3.svg',__FILE__ ); ?>" alt="Confirm Domain" /></span>
							<span class="wp-ssl-steps-name">Confirm Domain</span>
						</li>
						<li class="step-item">
							<span class="wp-ssl-steps-count"><img src="<?php echo plugins_url('images/step-4.svg',__FILE__ ); ?>" alt="Validation and Installation" /></span>
							<span class="wp-ssl-steps-name">Validation and Installation</span>
						</li>
					</ul>
				</div>
				<div id="cpanel-div" class="wp-ssl-left-block">
					<div class="loader" style="display: none;">
						<img src="<?php echo plugins_url('images/loager.gif',__FILE__ ); ?>" alt="Loading..." />
					</div>
					<?php if(empty($domainListArray)) { 
					    $httpsHost = 'https';
					    $cpnlUrl = $httpsHost.'://'.$_SERVER['SERVER_NAME'];
					?>
						<div id="cpanle-login-div">
							<h2 style="margin-top: 0"><img src="<?php echo plugins_url('images/cpanel-logo.svg',__FILE__ ); ?>" alt="cPanel" class="cpanel-logo" /></h2>
							<table width="100%;" class="login-table">
								<tbody>
									<tr>
										<td>
											<input type="text" class="text-input cpanel-url" id="cpanelLoginURL" name="cpanelLoginURL" autocomplete="off" value="<?php echo $cpnlUrl; ?>" placeholder="cPanel URL (https://domain-name.com)">
											<input type="text" class="text-input cpanel-port" id="cpanelPort" name="cpanelPort" autocomplete="off" value="2083" placeholder="Port">
										</td>
									</tr>
									<tr>
										<td><input type="text" class="text-input" id="cpanelUserName" name="cpanelUserName" autocomplete="off" placeholder="cPanel Username"></td>
									</tr>
									<tr>
										<td><input type="password" class="text-input" id="cpanelPassword" name="cpanelPassword" autocomplete="off"  placeholder="cPanel Password"></td>
									</tr>
									<tr>
										<td><input type="button" id="validateCpanel" name="validateCpanel" value="Next" class="button button-primary button-large button-orange"></td>
									</tr>
								</tbody>
							</table>
						</div>
					<?php } else { 
							if( strtolower($ValidateLicenseKeyResponse['CertificateStatus']) == 'completed'){
								$isReissue = 1;

								if(!empty($pinData)){
									$tempCertificateId = $pinData['tempCertificateId'];
								}
							}
	
						$selectDisable = '';
						$cpanelValidDomain = true;
						if( trim($ValidateLicenseKeyResponse['DomainName']) != ''){
							$selectDisable = 'disabled';

							if(!in_array(trim($ValidateLicenseKeyResponse['DomainName']), $domainListArray)){
								$cpanelValidDomain = false;
							}
						}
					?>
						<div id="install-domain" class="domain-list-div">
							<h2 style="margin-top: 0; display: inline-block;">Select Domain Name</h2>
							
							<table class="login-table" role="presentation" width="100%">
								<tbody>
									<tr>
										<td>
											<?php if($cpanelValidDomain) { ?>
												<select class="input-select" id="install-domain-name" name="domain" <?php echo $selectDisable; ?>>
													<?php if( isset($ValidateLicenseKeyResponse['CAOrderNumber']) && $ValidateLicenseKeyResponse['CAOrderNumber'] != '' ){ ?>
														<?php foreach($domainListArray as $dmnlist) { ?>
															<?php if( $ValidateLicenseKeyResponse['DomainName'] == $dmnlist ) { ?>
																<option value="<?php echo $dmnlist; ?>"><?php echo $dmnlist; ?></option>
															<?php } ?>
														<?php } ?>
													<?php } else { ?>	
														<?php foreach($domainListArray as $dmnlist) { ?>
															<option value="<?php echo $dmnlist; ?>"><?php echo $dmnlist; ?></option>
														<?php } ?>
													<?php } ?>
												</select>
											<?php } else { ?>
												<div class="ntc ntc-error">
											        <p><?php echo $ValidateLicenseKeyResponse['DomainName']; ?> : domain name not found in cpanel account, so change cpanel account.</p>
											    </div> 
											<?php } ?>
										</td>
									</tr>
									<tr>
										<td>
											<?php if($cpanelValidDomain) { ?>
												<?php if($isReissue == 1){ ?>
													<?php if( $tempCertificateId != '' ){ ?>
														<?php if($ValidateLicenseKeyResponse['DVCMethod'] == 'FILE'){ ?>
															<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Reinstall" class="button button-primary button-large button-orange">
														<?php } else { ?>
															<input type="button" id="continueProcess" name="tryAgainCert" value="Reinstall" class="button button-primary button-large button-orange">
														<?php } ?>
													<?php } else { ?>
														<input type="button" id="reissueCert" name="reissueCert" value="Reinstall" class="button button-primary button-large button-orange">
													<?php } ?>
												<?php } else { ?>	
													<?php if( isset($ValidateLicenseKeyResponse['CAOrderNumber']) && $ValidateLicenseKeyResponse['CAOrderNumber'] != '' ){ ?>
														<?php if($ValidateLicenseKeyResponse['DVCMethod'] == 'FILE'){ ?>
															<input type="button" id="tryAgainCert" name="tryAgainCert" value="Install" class="button button-primary button-large button-orange">
														<?php } else { ?>
															<input type="button" id="continueProcess" name="tryAgainCert" value="Install" class="button button-primary button-large button-orange">
														<?php } ?>
													<?php } else { ?>
														<input type="button" id="installCert" name="installCert" value="Install" class="button button-primary button-large button-orange">
													<?php } ?>
												<?php } ?>
											<?php } ?>
											
											<div class="change-cpanel">Don’t see the domain or website name you want to secure? <a href="javascript:void(0);" id="changeCpanel">click here</a> to change your cPanel account.</div>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					
						<?php 
							if($cpanelValidDomain){
								$btnText = '';
								if($isReissue == 1){
									if( $tempCertificateId != '' ){ 
								 		$stp1 = $stp2 = 'active'; 
								 		if($ValidateLicenseKeyResponse['DVCMethod'] == 'DNS'){
								 			$btnText = '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn" style="display:none;">';
								 			$btnText .= '<input type="button" id="checkdns" value="Check DNS" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
								 		}else{
								 			$btnText = '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
								 		}
								 	} else { 
								 		$stp1 = $stp2 = '';
								 	}
								}else{
									if( isset($ValidateLicenseKeyResponse['CAOrderNumber']) && $ValidateLicenseKeyResponse['CAOrderNumber'] != '' ){
								 		$stp1 = $stp2 = 'active'; 
								 		if($ValidateLicenseKeyResponse['DVCMethod'] == 'DNS'){
								 			$btnText = '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn" style="display:none;">';
								 			$btnText .= '<input type="button" id="checkdns" value="Check DNS" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
								 		}else{
								 			$btnText = '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
								 		}
								 	} else { 
								 		$stp1 = $stp2 = '';
								 	}
							 	}

							 	$dcvMethodText = '';
							 	$dcvInfo = '';
							 	if($stp1 == 'active'){
							 		if($ValidateLicenseKeyResponse['DVCMethod'] == 'EMAIL'){
							 			$approvalEmail = $ValidateLicenseKeyResponse['ApprovalEmail'];
							 			$dcvMethodText .= 'Please check <strong>'.$approvalEmail.'</strong> mailbox for an email received from Certificate Authority. That email contains all information to complete the verification process. If you have not received an email yet, please wait for a few minutes. 
Complete the email verification process and click on the CONTINUE button.';
							 		}else if($ValidateLicenseKeyResponse['DVCMethod'] == 'DNS'){
							 			$dcvMethodText .= nl2br($ValidateLicenseKeyResponse['DCVInfo']['DCVDNSContent']);

							 			$dcvInfo = '<div class="dcv-note"><span>Please create a valid DNS record as per the above details.</span>
                                                    1. Log into your domain’s hosting Control Panel (typically the registrar of your domain)<br/>
                                                    2. Locate and select the DNS Zone Manager for your desired domain. <br/>
                                                    3. Select the option to create a new record.</div>';
									}
							 	}



							 	$wildcardDomainList = $dcvInfo;
							 	if($ValidateLicenseKeyResponse['IsWildcard'] == 1 && $ValidateLicenseKeyResponse['DomainName'] != ''){
							 		$domainNameStarWithout = ltrim($ValidateLicenseKeyResponse['DomainName'],'*');

							 		$wildcardDomainList .= '<div class="wildcard-domain-list-div"><div class="wildcard-domain-list-title">Domains List</div>';
							 		$mainDomain = ltrim($ValidateLicenseKeyResponse['DomainName'],'*.');
									$wildcardDomainList .= '<span><input type="checkbox" class="wildcardDomain" value="'.$mainDomain.'" checked disabled>&nbsp;'.$mainDomain.'</span>';
									if(!empty($domainListArray)){
										foreach($domainListArray as $dmnItem){
											$dmnItem = ltrim($dmnItem,'*.');
											if(strpos($dmnItem, $domainNameStarWithout) !== false) {
												$wildcardDomainList .= '<span><input type="checkbox" class="wildcardDomain" value="'.$dmnItem.'">&nbsp;'.$dmnItem.'</span>';
											}
										}
									}

									$wildcardDomainList .= '</div>';
							 	}
							?>

							<div id="install-confirm-steps" class="confirm-step-div" style="display: none;">
								<ul>
									<li id="stp1" class="<?php echo $stp1; ?>">Preparing Request</li>	
									<li id="stp2" class="<?php echo $stp2; ?>">Requesting Certificate</li>
									<?php if($dcvMethodText){ ?>
										<div class="notice-dcv"><p><?php echo $dcvMethodText; ?></p></div>
										<?php echo $wildcardDomainList; ?>
										<?php echo $btnText; ?>
									<?php } ?>
									<li id="stp3">Domain Verification</li>
									<li id="stp4">Installing Certificate</li>	
								</ul>
								<div class="alertmsg-while-process">
									Please do not close this window or refresh page or click the Back button on your browser while process is running.
								</div>
							</div>
						<?php } ?>
					<?php } ?>
				</div>
			</div>
			<div class="wp-ssl-right">
				<?php include 'autossl-sidebar.php'; ?>
			</div>
		</div>
	<?php } ?>
</div>