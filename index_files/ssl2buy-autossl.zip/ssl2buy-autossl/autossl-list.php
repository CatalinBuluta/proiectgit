<?php
global $wpdb;
$msg = "";

class WPSSL_List_Table extends WP_List_Table 
{
	function __construct() {
		parent::__construct( array(
			'singular'=> 'wpssl', //Singular label
			'plural' => 'wpssls', //plural label, also this well be one of the table css class
			'ajax'	=> false //We won't support Ajax for this table
		) );
	}
	function get_columns() {
		return $columns= array(
			//'id'=>__('ID'),
			'pin'=>__('License Key'),
			'status'=>__('Status'),
			'domainName'=>__('Domain Name'),
			'expireOn'=>__('Expire On'),
			'action'=>__(''),
		);
	}
	function prepare_items($search='') 
    {
    	global $wpdb, $_wp_column_headers;
    	$screen = get_current_screen();
    	$columns = $this->get_columns();
    	$hidden = array();
    	$sortable = $this->get_sortable_columns();               
    	$this->_column_headers = array($columns, $hidden, $sortable);       
		// [OPTIONAL] process bulk action if any
    	$this->process_bulk_action();
    	/* -- Preparing your query -- */
    	$wpsslTableName = $wpdb->prefix . 'wpssl';
    	
    	$query = "SELECT * FROM $wpsslTableName";
    	if($search != NULL){
    		$search = trim($search);
    		$query = "SELECT * FROM $wpsslTableName WHERE pin LIKE '%".$search."%' OR status LIKE '%".$search."%' OR domainName LIKE '%".$search."%'";
    	}
    	/* -- Ordering parameters -- */
	    //Parameters that are going to be used to order the result
    	$orderby = !empty($_GET["orderby"]) ? $_GET["orderby"] : 'id';
    	$order = !empty($_GET["order"]) ? $_GET["order"] : 'DESC';
    	if(!empty($orderby) & !empty($order)){ $query.=' ORDER BY '.$orderby.' '.$order; }
    	/* -- Pagination parameters -- */
        //Number of elements in your table?
        $totalitems = $wpdb->query($query); //return the total number of affected rows
        //How many to display per page?
        $perpage = 15;
        //Which page is this?
        $paged = !empty($_GET["paged"]) ? $_GET["paged"] : '';
        //Page Number
        if(empty($paged) || !is_numeric($paged) || $paged<=0 ){ $paged=1; }
        //How many pages do we have in total?
        $totalpages = ceil($totalitems/$perpage);
        //adjust the query to take pagination into account
        if(!empty($paged) && !empty($perpage)){
        	$offset=($paged-1)*$perpage;
        	$query.=' LIMIT '.(int)$offset.','.(int)$perpage;
        }
        /* -- Register the pagination -- */
        $this->set_pagination_args( array(
        	"total_items" => $totalitems,
        	"total_pages" => $totalpages,
        	"per_page" => $perpage,
        ) );
		//The pagination links are automatically built according to those parameters
        /* -- Register the Columns -- */
        $columns = $this->get_columns();
        $_wp_column_headers[$screen->id]=$columns;
        /* -- Fetch the items -- */
        $data = $wpdb->get_results($query, ARRAY_A);
        $this->items = $data;
    }

    function no_items(){
		_e( 'No license key found.', 'sp' );
	}
	
	function column_default( $item, $column_name ){
		switch( $column_name ){
			//case 'id':
			//	return $item['id'];
			case 'pin':
				return $item[ 'pin' ];
			case 'status':
				if(strtolower($item['status']) == 'complete'){
					return '<span class="status-complete">'.$item['status'].'</span>';
				}else{
					return '<span class="status-awaiting-validation">'.$item['status'].'</span>';
				}
			case 'domainName':
				return $item['domainName'];
			case 'expireOn':
				return $item['expireOn'];
			case 'action':
				if(strtolower($item['status']) == 'complete'){
					return '<a class="button button-primary button-large button-orange button-orange-sm" href="?page=wp-ssl-cpanel&lkey='.$item[ 'pin' ].'">Reinstall</a>';
				}else{
					return '<a class="button button-primary button-large button-green button-green-sm" href="?page=wp-ssl-cpanel&lkey='.$item[ 'pin' ].'">Install</a>';
				}	
			default:
			return print_r( $item, true ) ; //Show the whole array for troubleshooting purposes
		}
	}
} //class
if(!class_exists('WP_List_Table')){
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}
$wp_list_table = new WPSSL_List_Table();
if( isset($_GET['s']) ){
	$wp_list_table->prepare_items($_GET['s']);
} else {
	$wp_list_table->prepare_items();
}

$current_user = wp_get_current_user();
?>
<div class="wrap wp-ssl-listing-main">
	<h1 class="wp-ssl-logo"><img src="<?php echo plugins_url('images/ssl2buy-auto-ssl-logo.svg',__FILE__ ); ?>" alt="SSL2BUY Auto SSL" /></h1>
	<div class="addnew-search">
		<div class="add-new-ssl"><span>Hi <?php echo $current_user->display_name; ?> ,</span> </br>
		AutoSSL Plugin is designed to fully automate SSL certificate installation process. No technical skill required and Get your certificate installed in 90 seconds. 
		
		<div class="lets-start-now"><span>Let's start now!</span><a class="page-title-action add-new button button-orange" href="?page=wp-ssl-add">Add New Certificate</a></div>
		</div>
	
		<form method="get" >
			<div class="search-box">
				<input type="hidden" name="page" value="<?php echo $_REQUEST['page'];?>" />
				<?php $wp_list_table->search_box('Search', 'wpssl'); ?>
			</div>
		</form>
		</div>
	<?php $wp_list_table->display(); ?>
</div>