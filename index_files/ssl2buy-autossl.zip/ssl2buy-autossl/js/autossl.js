(function($){ 
	function checkDomainPublicklyAccess(domainName){
		$('.loader').show();
		var str = 'action=wp_ssl_check_domain_public_access&pin='+ajax_vars.lkey+'&domainName='+domainName;
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
				$('.loader').hide();
				var resp = JSON.parse(res);
				if(resp.statusCode == 1){
					$('.sidebar-content-main').hide();
					$('.sidebar-content-installation').show();
					installCertificate();
				}else{
					$('.sidebar-content-main').hide();
					$('.sidebar-content-dcv').show();
					$('#install-domain').hide();
					$('#cpanel-div').prepend(resp.htmlContent);
					return false;
				}
			}
		});
	}

	function checkDomainPublicklyAccessReissue(domainName){
		$('.loader').show();
		var str = 'action=wp_ssl_check_domain_public_access&pin='+ajax_vars.lkey+'&domainName='+domainName+'&reissue=1';
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
				$('.loader').hide();
				var resp = JSON.parse(res);
				if(resp.statusCode == 1){
					$('.sidebar-content-main').hide();
					$('.sidebar-content-installation').show();
					reinstallCertificate();
				}else{
					$('.sidebar-content-main').hide();
					$('.sidebar-content-dcv').show();

					$('#install-domain').hide();
					$('#cpanel-div').prepend(resp.htmlContent);
					return false;
				}
			}
		});
	}

	function installCertificate(approvalMethod="", approvalEmail=""){
		$('#install-domain').hide();
		$('#domain-approval-list').hide();
		$('#continueCert').hide();
		$('#install-confirm-steps').show();

		$('#cpanel-div').find('.change-cpanel').remove();

		$('.wp-ssl-steps').find('li.active').removeClass('active').addClass('complete');
		$('.wp-ssl-steps').find('li:last').addClass('active');

		$('.wp-ssl-left-block').find('.notice').remove();
		$('.wp-ssl-left-block').find('.notice-dcv').remove();
		$('.wp-ssl-left-block').find('.ajax-btn').remove();
		$('.alertmsg-while-process').show();
        
        $('#install-confirm-steps').find('li').removeClass('running').removeClass('error').removeClass('active');
		$('#install-confirm-steps').find('#stp1').addClass('running');

		var domainName = $('#install-domain-name').val();

		var str = 'action=wp_ssl_install_cert&pin='+ajax_vars.lkey+'&domainName='+domainName+'&approvalMethod='+approvalMethod+'&approvalEmail='+approvalEmail;
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
		    	const respArray = res.split("||");
				var len = respArray.length;
				len = len - 1;

				var resp = JSON.parse(respArray[len]);
				if(resp.statusCode == 1 ){
					var msg = '<div class="notice notice-success is-dismissible"><p>'+resp.message+'</p></div>';
					var btnHtml = '';
				} else if(resp.statusCode == 2 ){
					var msg = '<div class="notice-dcv is-dismissible"><p>'+resp.message+'</p></div>';
					if(approvalMethod == 'DNS'){
						var checkDNSBTN = '<input type="button" id="checkdns" value="Check DNS" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
						$( checkDNSBTN ).insertAfter( '.wp-ssl-left-block #stp2' );
						
						var btnHtml = '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn" style="display:none;">';
					}else{
						var btnHtml = '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
					}
				}else{
					if(resp.message != ''){
						var msg = '<div class="notice notice-error is-dismissible"><p>'+resp.message+'</p></div>';
					}else{
						var msg = '';
					}

					$('#install-confirm-steps').find('li.running').removeClass('running').addClass('error');

					if(resp.pinOrderNumber != ''){
						var btnHtml = '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Try Again" class="button button-primary button-large button-orange ajax-btn">';
					}else{
						var btnHtml = '<input type="button" id="installCert" name="installCert" value="Try Again" class="button button-primary button-large button-orange ajax-btn">';
					}
				}

				$('.alertmsg-while-process').hide();
				if(resp.statusCode == 2 ){
					$( btnHtml ).insertAfter( '.wp-ssl-left-block #stp2' );
					$( resp.wildcardDomainList ).insertAfter( '.wp-ssl-left-block #stp2' );
					$( msg ).insertAfter( '.wp-ssl-left-block #stp2' );
				}else{
					$('.wp-ssl-left-block').append(msg);
					$('.wp-ssl-left-block').append(btnHtml);
				}
			},
			xhr: function(){
		    	var xhr = $.ajaxSettings.xhr();
		    	xhr.onprogress = function(evt){ 
		    		
		    		var respArray1 = evt.currentTarget.responseText.split("||");
					var len1 = respArray1.length;
					len1 = len1 - 2;
					
					var splitString = $.trim(respArray1[len1]);
					if(approvalMethod == '' || approvalMethod == 'FILE'){
						$('#'+splitString).removeClass('running').removeClass('error').addClass('active').next().addClass('running');
					}else{
						if(splitString == 'stp2'){
							$('#'+splitString).removeClass('running').removeClass('error').addClass('active');
						}else{
							$('#'+splitString).removeClass('running').removeClass('error').addClass('active').next().addClass('running');
						}	
					}	
					
				};
		        return xhr;
		    },
		});
	}

	function reinstallCertificate(approvalMethod="", approvalEmail=""){
		$('#install-domain').hide();
		$('#reissue-domain-approval-list').hide();
		$('#continueReissueCert').hide();
		$('#install-confirm-steps').show();

		$('#cpanel-div').find('.change-cpanel').remove();

		$('.wp-ssl-steps').find('li.active').removeClass('active').addClass('complete');
		$('.wp-ssl-steps').find('li:last').addClass('active');

		$('.wp-ssl-left-block').find('.notice').remove();
		$('.wp-ssl-left-block').find('.notice-dcv').remove();
		$('.wp-ssl-left-block').find('.ajax-btn').remove();
		$('.alertmsg-while-process').show();
        
        $('#install-confirm-steps').find('li').removeClass('running').removeClass('error').removeClass('active');
		$('#install-confirm-steps').find('#stp1').addClass('running');

		var domainName = $('#install-domain-name').val();

		var str = 'action=wp_ssl_reissue_cert&pin='+ajax_vars.lkey+'&domainName='+domainName+'&approvalMethod='+approvalMethod+'&approvalEmail='+approvalEmail;
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr){ 
		    	const respArray = res.split("||");
				var len = respArray.length;
				len = len - 1;

				var resp = JSON.parse(respArray[len]);
				if(resp.statusCode == 1 ){
					var msg = '<div class="notice notice-success is-dismissible"><p>'+resp.message+'</p></div>';
					var btnHtml = '';
				} else if(resp.statusCode == 2 ){
					var msg = '<div class="notice-dcv is-dismissible"><p>'+resp.message+'</p></div>';
					if(approvalMethod == 'DNS'){
						var checkDNSBTN = '<input type="button" id="checkdnsReissue" value="Check DNS" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
						$( checkDNSBTN ).insertAfter( '.wp-ssl-left-block #stp2' );	
						var btnHtml = '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn" style="display:none;">';
					}else{
						var btnHtml = '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
					}
				}else{
					if(resp.message != ''){
						var msg = '<div class="notice notice-error is-dismissible"><p>'+resp.message+'</p></div>';
					}else{
						var msg = '';
					}

					$('#install-confirm-steps').find('li.running').removeClass('running').addClass('error');

					if(resp.tempCertificateId != ''){
						var btnHtml = '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Try Again" class="button button-primary button-large button-orange ajax-btn">';
					}else{
						var btnHtml = '<input type="button" id="reissueCert" name="reissueCert" value="Try Again" class="button button-primary button-large button-orange ajax-btn">';
					}
				}

				$('.alertmsg-while-process').hide();
				if(resp.statusCode == 2 ){
					$( btnHtml ).insertAfter( '.wp-ssl-left-block #stp2' );
					$( resp.wildcardDomainList ).insertAfter( '.wp-ssl-left-block #stp2' );
					$( msg ).insertAfter( '.wp-ssl-left-block #stp2' );
				}else{
					$('.wp-ssl-left-block').append(msg);
					$('.wp-ssl-left-block').append(btnHtml);
				}
				
			},
			xhr: function(){
		    	var xhr = $.ajaxSettings.xhr();
		    	xhr.onprogress = function(evt){ 
		    		var respArray1 = evt.currentTarget.responseText.split("||");
					var len1 = respArray1.length;
					len1 = len1 - 2;
					
					var splitString = $.trim(respArray1[len1]);
					if(approvalMethod == '' || approvalMethod == 'FILE'){
						$('#'+splitString).removeClass('running').removeClass('error').addClass('active').next().addClass('running');
					}else{
						if(splitString == 'stp2'){
							$('#'+splitString).removeClass('running').removeClass('error').addClass('active');
						}else{
							$('#'+splitString).removeClass('running').removeClass('error').addClass('active').next().addClass('running');
						}	
					}	
					
				};
		        return xhr;
		    },
		});
	}

	$(document).on('click', '#checkdns', function(){
		$('.loader').show();
		$('.check-dns-notice').remove();
		var str = 'action=wp_ssl_check_dns&pin='+ajax_vars.lkey;
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
				$('.loader').hide();
				var resp = JSON.parse(res);
				if(resp.statusCode == 1){
					$('#tryAgainCert').trigger('click');
				}else{
					var msg = '<div class="notice notice-error is-dismissible check-dns-notice"><p>'+resp.errorMSG+'</p></div>';
					$( msg ).insertAfter( '#checkdns' );
				}
			}
		});
	});

	$(document).on('click', '#checkdnsReissue', function(){
		$('.loader').show();
		$('.check-dns-notice').remove();
		var str = 'action=wp_ssl_check_dns&pin='+ajax_vars.lkey;
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
				$('.loader').hide();
				var resp = JSON.parse(res);
				if(resp.statusCode == 1){
					$('#tryAgainReissueCert').trigger('click');
				}else{
					var msg = '<div class="notice notice-error is-dismissible check-dns-notice"><p>'+resp.errorMSG+'</p></div>';
					$( msg ).insertAfter( '#checkdnsReissue' );
				}
			}
		});
	});

	$(document).on('change', '.select-approval-method', function(){
		var domainName = $('#install-domain-name').val();
		var selectApprovalMethod =  $.trim($(this).val());

		var currentTarget = $(this).parents('.domain-approval-item').find('.domain-approval-item-left p');

		$('.domain-approval-item').removeClass('active');
		$(this).parents('.domain-approval-item').addClass('active');

		$("#domain-approval-email-list-div").remove();
		$("#continueCert").remove();
		$(".notice").remove();

		if(selectApprovalMethod == 'EMAIL'){
			$('.loader').show();
			var str = 'action=wp_ssl_get_apporval_email_list&domainName='+domainName;
			$.ajax({
				method: 'post',
				url: ajax_vars.ajaxurl,
				data: str,
				success: function(res,status,xhr) { 
					$('.loader').hide();
					var resp = JSON.parse(res);
					if(resp.statusCode == 1){
						$( resp.htmlContent ).insertAfter( currentTarget );
						$('<input type="button" id="continueCert" name="continueCert" value="Continue" class="button button-primary button-large button-orange">').insertAfter( $('#domain-approval-list') );
					}else{
						var msg = '<div class="notice notice-error is-dismissible"><p>'+resp.htmlContent+'</p></div>';
						$( msg ).insertAfter( currentTarget );
					}
				}
			});
		}else{
			$('<input type="button" id="continueCert" name="continueCert" value="Continue" class="button button-primary button-large button-orange">').insertAfter( $('#domain-approval-list') );
		}
	});

	$(document).on('change', '.reissue-select-approval-method', function(){
		var domainName = $('#install-domain-name').val();
		var selectApprovalMethod =  $.trim($(this).val());

		var currentTarget = $(this).parents('.domain-approval-item').find('.domain-approval-item-left p');

		$('.domain-approval-item').removeClass('active');
		$(this).parents('.domain-approval-item').addClass('active');

		$("#domain-approval-email-list-div").remove();
		$(".notice").remove();
		$("#continueReissueCert").remove();

		if(selectApprovalMethod == 'EMAIL'){
			$('.loader').show();
			var str = 'action=wp_ssl_get_apporval_email_list&domainName='+domainName;
			$.ajax({
				method: 'post',
				url: ajax_vars.ajaxurl,
				data: str,
				success: function(res,status,xhr) { 
					$('.loader').hide();
					var resp = JSON.parse(res);
					if(resp.statusCode == 1){
						$( resp.htmlContent ).insertAfter( currentTarget );
						$('<input type="button" id="continueReissueCert" name="continueReissueCert" value="Continue" class="button button-primary button-large button-orange">').insertAfter( $('#reissue-domain-approval-list') );
					}else{
						var msg = '<div class="notice notice-error is-dismissible"><p>'+resp.htmlContent+'</p></div>';
						$( msg ).insertAfter( currentTarget );
					}
				}
			});
		}else{
			$('<input type="button" id="continueReissueCert" name="continueReissueCert" value="Continue" class="button button-primary button-large button-orange">').insertAfter( $('#reissue-domain-approval-list') );
		}
	});

	$(document).on('click', '#add-license-key #checkPin', function(){
		var lky = $.trim($('#configPin').val());
		var str = 'action=wp_ssl_validate_pin&pin='+lky;

		$('#add-license-key').find('#key-detail').remove();
		$('#add-license-key').find('.notice').remove();
		$('.loader').show();
		
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
				var resp = JSON.parse(res);
				if(resp.statusCode == 1){
					if(resp.isRedirect == 1){
						window.location.href = "admin.php?page=wp-ssl-cpanel&lkey="+lky;
					}else{
						$('#div-add-lkey').hide();
						$('#add-license-key').append(resp.htmlContent);
					}
				}else{
					var errorMSG = '<div class="notice notice-error is-dismissible"><p>'+resp.errorMessage+'</p></div>';
					$('#add-license-key').append(errorMSG);
				}

				$('.loader').hide();
			}
		});
	});

	$(document).on('click', '#changeKey', function(){
		$('#key-detail').remove();
		$('#configPin').val('');
		$('#div-add-lkey').show();
	});

	$(document).on('click', '#cpanel-div #validateCpanel', function(){
		var cpanelLoginURL = $.trim($('#cpanelLoginURL').val());
		var cpanelPort = $.trim($('#cpanelPort').val());
		var cpanelUserName = $.trim($('#cpanelUserName').val());
		var cpanelPassword = $('#cpanelPassword').val();

		$('#cpanel-div').find('.notice').remove();
		$('#cpanel-div').find('#install-domain').remove();
		$('#cpanel-div').find('#install-confirm-steps').remove();

		$('.loader').show();

		var str = 'action=wp_ssl_validate_cpanel&pin='+ajax_vars.lkey+'&cpanelLoginURL='+encodeURIComponent(cpanelLoginURL)+'&cpanelPort='+encodeURIComponent(cpanelPort)+'&cpanelUserName='+encodeURIComponent(cpanelUserName)+'&cpanelPassword='+encodeURIComponent(cpanelPassword);
		
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
				var resp = JSON.parse(res);
				if(resp.statusCode == 1){
					$('.wp-ssl-steps .step-item.active').removeClass('active').addClass('complete').next().addClass('active');

					$('#cpanle-login-div').remove();
					$('#cpanel-div').append(resp.htmlContent);
					$('.sidebar-content-main').hide();
					$('.sidebar-content-select-domain').show();
				}else{
					var errorMSG = '<div class="notice notice-error is-dismissible"><p>'+resp.errorMessage+'</p></div>';
					$('#cpanel-div').append(errorMSG);
				}

				$('.loader').hide();
			}
		});
	});

	$(document).on('click', '#changeCpanel', function(){
		$('.loader').show();

		var str = 'action=wp_ssl_change_cpanel&pin='+ajax_vars.lkey;
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
				var resp = JSON.parse(res);
				
				$('.wp-ssl-steps .step-item.active').removeClass('active').prev().removeClass('complete').addClass('active');

				$('#cpanel-div').find('#domain-approval-list').remove();
				$('#cpanel-div').find('#domain-approval-email-list-div').remove();
				$('#cpanel-div').find('#install-domain').remove();
				$('#cpanel-div').find('#install-confirm-steps').remove();
				$('#cpanel-div').find('.change-cpanel').remove();

				$('#cpanel-div').append(resp.htmlContent);
				
				$('.sidebar-content-main').hide();
				$('.sidebar-content-cpanel').show();

				$('.loader').hide();
			}
		});
	});

	$(document).on('click', '#installCert', function(){
		var domainName = $('#install-domain-name').val();
		if( $('#domain-approval-list').length > 0 ){
			
			$('.sidebar-content-main').hide();
			$('.sidebar-content-installation').show();
			
			installCertificate();
		} else {
			checkDomainPublicklyAccess(domainName);
		}
	});

	$(document).on('click', '#reissueCert', function(){
		var domainName = $('#install-domain-name').val();
		if( $('#reissue-domain-approval-list').length > 0 ){
			$('.sidebar-content-main').hide();
			$('.sidebar-content-installation').show();

			reinstallCertificate();
		} else {
			checkDomainPublicklyAccessReissue(domainName);
		}
	});

	$(document).on('click', '#continueCert', function(){
		$('.notice').remove();
		var approvalMethod = $('.select-approval-method:checked').val();
		if(approvalMethod == 'EMAIL'){
			var approvalEmail = $('#domain-approval-email-list').val();
			if($.trim(approvalEmail) != ''){
				$('.sidebar-content-main').hide();
				$('.sidebar-content-installation').show();

				installCertificate(approvalMethod, approvalEmail);
			}else{
				var errorMSG = '<div class="notice notice-error is-dismissible"><p>Please select approval email</p></div>';
				$( errorMSG ).insertBefore( '#continueCert' );
			}
		}else{
			$('.sidebar-content-main').hide();
			$('.sidebar-content-installation').show();
			installCertificate(approvalMethod);
		}
		
	});

	$(document).on('click', '#continueReissueCert', function(){
		$('.notice').remove();
		var approvalMethod = $('.reissue-select-approval-method:checked').val();
		if(approvalMethod == 'EMAIL'){
			var approvalEmail = $('#domain-approval-email-list').val();
			if($.trim(approvalEmail) != ''){
				$('.sidebar-content-main').hide();
			    $('.sidebar-content-installation').show();
				reinstallCertificate(approvalMethod, approvalEmail);
			}else{
				var errorMSG = '<div class="notice notice-error is-dismissible"><p>Please select approval email</p></div>';
				$( errorMSG ).insertBefore( '#continueReissueCert' );
			}
		}else{
			$('.sidebar-content-main').hide();
			$('.sidebar-content-installation').show();
			reinstallCertificate(approvalMethod);
		}
		
	});

	$(document).on('click', '#tryAgainCert', function(){
		$('#install-domain').hide();
		$('#install-confirm-steps').show();

		$('#cpanel-div').find('.change-cpanel').remove();

		$('.wp-ssl-steps').find('li.active').removeClass('active').addClass('complete');
		$('.wp-ssl-steps').find('li:last').removeClass('complete').addClass('active');

		$('.wp-ssl-left-block').find('.notice').remove();
		$('.wp-ssl-left-block').find('.ajax-btn').remove();
		$('.alertmsg-while-process').show();

		$('#install-confirm-steps').find('#stp3').removeClass('error').addClass('running');

		var domainName = $('#install-domain-name').val();
		

		var wildCardDomain = '';
		$('.wildcard-domain-list-div').find('.wildcardDomain:checked').each(function(){
			var dmnNM = $(this).val();
			wildCardDomain += dmnNM+'||';
		});

		if( $('.select-approval-method').length > 0 ) { 
			var approvalMethod = $('.select-approval-method:checked').val();
		} else { 
			var approvalMethod = '';
		};
		
		var str = 'action=wp_ssl_install_try_cert&pin='+ajax_vars.lkey+'&domainName='+domainName+'&approvalMethod='+approvalMethod+'&wildcardDomainList='+encodeURIComponent(wildCardDomain);
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr) { 
		    	const respArray = res.split("||");
				var len = respArray.length;
				len = len - 1;

				var resp = JSON.parse(respArray[len]);
				if(resp.statusCode == 1 ){
					var msg = '<div class="notice notice-success is-dismissible"><p>'+resp.message+'</p></div>';
					var btnHtml = '';
					$('.wp-ssl-left-block').find('.notice-dcv').remove();
					$('.wp-ssl-left-block').find('.wildcard-domain-list-div').remove();
					$('.wp-ssl-left-block').find('.dcv-note').remove();
				}else{
					if(resp.message != ''){
						var msg = '<div class="notice notice-error is-dismissible"><p>'+resp.message+'</p></div>';
					}else{
						var msg = '';
					}

					$('#install-confirm-steps').find('li.running').removeClass('running').addClass('error');

					if(resp.pinOrderNumber != ''){
						var btnHtml = '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Try Again" class="button button-primary button-large button-orange ajax-btn">';
					}else{
						var btnHtml = '<input type="button" id="installCert" name="installCert" value="Try Again" class="button button-primary button-large button-orange ajax-btn">';
					}
				}

				$('.alertmsg-while-process').hide();
				$('.wp-ssl-left-block').append(msg);
				$('.wp-ssl-left-block').append(btnHtml);
			},
			xhr: function(){
		    	var xhr = $.ajaxSettings.xhr();
		    	xhr.onprogress = function(evt){ 
		    		
		    		var respArray1 = evt.currentTarget.responseText.split("||");
					var len1 = respArray1.length;
					len1 = len1 - 2;
					
					var splitString = $.trim(respArray1[len1]);
					$('#'+splitString).removeClass('running').removeClass('error').addClass('active').next().addClass('running');
				};
		        return xhr;
		    },
		});
	});

	$(document).on('click', '#continueProcess', function(){
		$('.wp-ssl-steps').find('li.active').removeClass('active').addClass('complete');
		$('.wp-ssl-steps').find('li:last').addClass('active');
		
		$('.sidebar-content-main').hide();
		$('.sidebar-content-installation').show();

		$('#install-domain').hide();
		$('#install-confirm-steps').show();
		$('.alertmsg-while-process').hide();
	});

	$(document).on('click', '#tryAgainReissueCert', function(){
		$('#install-domain').hide();
		$('#install-confirm-steps').show();

		$('#cpanel-div').find('.change-cpanel').remove();

		$('.wp-ssl-steps').find('li.active').removeClass('active').addClass('complete');
		$('.wp-ssl-steps').find('li:last').removeClass('complete').addClass('active');

		$('.wp-ssl-left-block').find('.notice').remove();
		//$('.wp-ssl-left-block').find('.notice-dcv').remove();
		$('.wp-ssl-left-block').find('.ajax-btn').remove();
		$('.alertmsg-while-process').show();

		$('#install-confirm-steps').find('#stp3').removeClass('error').addClass('running');

		var domainName = $('#install-domain-name').val();

		var wildCardDomain = '';
		$('.wildcard-domain-list-div').find('.wildcardDomain:checked').each(function(){
			var dmnNM = $(this).val();
			wildCardDomain += dmnNM+'||';
		});

		if( $('.reissue-select-approval-method').length > 0 ) { 
			var approvalMethod = $('.reissue-select-approval-method:checked').val();
		} else { 
			var approvalMethod = '';
		};

		var str = 'action=wp_ssl_reissue_try_cert&pin='+ajax_vars.lkey+'&domainName='+domainName+'&approvalMethod='+approvalMethod+'&wildcardDomainList='+encodeURIComponent(wildCardDomain);
		$.ajax({
			method: 'post',
			url: ajax_vars.ajaxurl,
			data: str,
			success: function(res,status,xhr){ 
		    	const respArray = res.split("||");
				var len = respArray.length;
				len = len - 1;

				var resp = JSON.parse(respArray[len]);
				if(resp.statusCode == 1 ){
					var msg = '<div class="notice notice-success is-dismissible"><p>'+resp.message+'</p></div>';
					var btnHtml = '';
					$('.wp-ssl-left-block').find('.notice-dcv').remove();
					$('.wp-ssl-left-block').find('.wildcard-domain-list-div').remove();
					$('.wp-ssl-left-block').find('.dcv-note').remove();
				}else{
					if(resp.message != ''){
						var msg = '<div class="notice notice-error is-dismissible"><p>'+resp.message+'</p></div>';
					}else{
						var msg = '';
					}
						
					$('#install-confirm-steps').find('li.running').removeClass('running').addClass('error');

					if(resp.tempCertificateId != ''){
						var btnHtml = '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Try Again" class="button button-primary button-large button-orange ajax-btn">';
					}else{
						var btnHtml = '<input type="button" id="reissueCert" name="reissueCert" value="Try Again" class="button button-primary button-large button-orange ajax-btn">';
					}
				}

				$('.alertmsg-while-process').hide();
				$('.wp-ssl-left-block').append(msg);
				$('.wp-ssl-left-block').append(btnHtml);
			},
			xhr: function(){
		    	var xhr = $.ajaxSettings.xhr();
		    	xhr.onprogress = function(evt){ 
		    		
		    		var respArray1 = evt.currentTarget.responseText.split("||");
					var len1 = respArray1.length;
					len1 = len1 - 2;
					
					var splitString = $.trim(respArray1[len1]);
					$('#'+splitString).removeClass('running').removeClass('error').addClass('active').next().addClass('running');
				};
		        return xhr;
		    },
		});
	});
})(jQuery);