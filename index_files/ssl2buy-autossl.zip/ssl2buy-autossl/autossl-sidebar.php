<div class="sidebar-top">
    <div class="feedback-form-banner">
    <div class="feedback-content">
        <h3>Tell us how we can improve</h3>
        <p>suggestions, error, feedback, etc.</p>
    </div>
    <div class="feedback-btn">
        <a href="javascript:void(0)" class="feedback-popup">Share review</a>
    </div>
</div>
	<script>
		jQuery(document).ready(function(){
			jQuery('.feedback-popup').click(function(){
				jQuery('.feedback-popup-content').show();
			});
			jQuery('.feedback-close').click(function(){
				jQuery('.feedback-popup-content').hide();
			});
			
			jQuery(window).click(function() {
				jQuery('.feedback-popup-content').hide();
			});

			jQuery('.feedback-popup-content-iframe, .feedback-popup').click(function(event){
				event.stopPropagation();
			});
			
		});
		jQuery(document).keydown(function(e) {
			if (e.keyCode === 27) {
				jQuery(".feedback-popup-content").hide();
			}
		});
	</script>
	<div class="feedback-popup-content" style="display: none" >
		<div class="feedback-popup-content-iframe">
			<div class="feedback-popup-content-title">Please share your review</div>
			<div class="feedback-close"></div>
			<div class="feedback-popup-content-inner">
			<iframe src="https://www.ssl2buy.com/feedback-form" width="100%" style="frameborder: 0; border: 0; margin: 0 auto;"></iframe>
				</div>
			</div>
		</div>
</div>
<div class="sidebar-bottom">
  <div class="sidebar-title">Quick Guide</div>
  
  <!-- License Key -->
	<?php $adminPage = ( isset($_GET['page']) && trim($_GET['page']) != '' ) ? trim($_GET['page']) : '';
    	  if($adminPage == 'wp-ssl-add'){
	?>
  <div class="sidebar-content-main sidebar-content-license-key">
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>What is License Key</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>A license is required to confirm your certificate license with SSL2BUY account.</p>
      </div>
    </div>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Where I can find my license key?</h2>
      </div>
      <div class="wp-ssl-right-block-content">You can find the license key on order details page in your SSL2BUY account. </div>
    </div>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Error: Invalid License Key</h2>
      </div>
      <div class="wp-ssl-right-block-content">Please make sure you're using active and valid certficate license key.</div>
    </div>
  </div>
	
  <!-- License Key--> 
	<?php } else{?>
  <!-- cPanel -->
  <div class="sidebar-content-main sidebar-content-cpanel" <?php if(isset($_SESSION['cpanelData'][$pin])) { ?>style="display: none"<?php } ?>>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Where I can find cPanel login details?</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>You can find cPanel login information in the HOSTING provider's portal.</p>
      </div>
    </div>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>I do not have cPanel hosting, what is next?</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>AutoSSL plugin works with WordPress with cPanel hosting environment only.</p>
      </div>
    </div>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Do you store or save cPanel login credentials?</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>NO, this plugin DOES NOT store or save your cPanel login credentials. The plugin use cPanel session to install the SSL certificate and the session will be terminated automatically.</p>
      </div>
    </div>
  </div>
  <!-- cPanel--> 
  
  <div class="sidebar-content-main sidebar-content-select-domain" <?php if(!isset($_SESSION['cpanelData'][$pin])) { ?>style="display: none"<?php } ?>>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Select Domain Name</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>Please select a domain name or website name you want to secure.</p>
      </div>
    </div>
  </div>
	
	
  <!-- DCV -->
  <div class="sidebar-content-main sidebar-content-dcv" style="display: none">
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>What is Domain Control Verification?</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>As per the CA/B community, The certificate requestor must demonstrate domain or website control or ownership to generate a valid SSL certificate license. It is a mandatory process. You cannot change the DCV method, make sure to select the correct option.</p>
      </div>
    </div>
  </div>
  
  <!-- DCV-->
  <div class="sidebar-content-main sidebar-content-installation" style="display: none">
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Preparing Request</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>The tool will automatically create a CSR key and send it to Certificate Authority to request the certificate.</p>
      </div>
    </div>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Requesting Certificate</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>The tool will send CSR key and Domain approval method preferences to Certificate  Authority. </p>
      </div>
    </div>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Domain Verification</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>Please complete the domain verification process to receive the certificate.</p>
      </div>
    </div>
    <div class="wp-ssl-right-block">
      <div class="wp-ssl-right-block-title">
        <h2>Installing Certificate</h2>
      </div>
      <div class="wp-ssl-right-block-content">
        <p>The tool will automatically install SSL certificate on selected website(s).</p>
      </div>
    </div>
  </div>
	<?php } ?>
</div>

