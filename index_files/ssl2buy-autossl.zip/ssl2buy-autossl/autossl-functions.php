<?php
	function insertDataInLocalStorage($pin, $status){
		global $wpdb;
		
		if($pin != ''){
			$wpsslTableName = $wpdb->prefix . 'wpssl';
			$pinDetails = $wpdb->get_row("SELECT * FROM $wpsslTableName WHERE pin = '$pin' ", ARRAY_A );
			if(empty($pinDetails)){
				$wpdb->insert($wpsslTableName, array(
				    "pin" => $pin,
					"status" => $status,
				));
			}	
		}
	}

	function getPinDetailFromLocalStorage($pin){
		global $wpdb;
		$wpsslTableName = $wpdb->prefix . 'wpssl';
		$pinDetails = $wpdb->get_row("SELECT * FROM $wpsslTableName WHERE pin = '$pin' ", ARRAY_A );
		if(!empty($pinDetails)){
			return $pinDetails;
		}else{
			return array();
		}
	}

	function updatePinDateInLocalStorage($pin, $status, $domainName="", $certificateId="", $expireOn="", $tempCertificateID = "", $reissueDone = ""){
		global $wpdb;

		$updateDataArray = array();
		$updateDataArray['status'] = $status;
		$updateDataArray['domainName'] = $domainName;
		$updateDataArray['certificateId'] = $certificateId;
		$updateDataArray['expireOn'] = $expireOn;
		$updateDataArray['tempCertificateId'] = $tempCertificateID;

		$updateString = '';
		if(!empty($updateDataArray)){
			foreach($updateDataArray as $updateItemKey => $updateItemVal){
				if($updateItemVal != ''){
					$updateString .= $updateItemKey.' = "'.$updateItemVal.'", ';
				}	
			}
		}	

		$wpsslTableName = $wpdb->prefix . 'wpssl';
		if($updateString){
			$updateString = rtrim($updateString, ', ');
			$wpdb->query("UPDATE $wpsslTableName SET $updateString WHERE pin = '$pin' ");
		}

		if($reissueDone == 1){
			$wpdb->query("UPDATE $wpsslTableName SET tempCertificateId = '' WHERE pin = '$pin' ");				
		}
	}

	function loginCpanel($domainUrl, $cpanelUserName, $cpanelPassword){ 
		$url = $domainUrl."/login";
		
		$post_data = array(
			'user' => $cpanelUserName,
			'pass' => $cpanelPassword,
		);
		$data_string = json_encode($post_data);  

		$ch = curl_init($url);          
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);                                                            
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);      
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);                                                                
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Accept: application/json','Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string))                                                                       
		);                                                                                                                   
		 
		$f = curl_exec($ch);
		$h = curl_getinfo($ch);

		$statusCode = 1;
		$message = '';
		if(curl_errno($ch)){
			$statusCode = 0;
			$message = curl_error($ch);
		}
		curl_close($ch);

		if ($f == true and strpos($h['url'],"cpsess")){
		    $pattern="/.*?(\/cpsess.*?)\/.*?/is";
		    $preg_res=preg_match($pattern,$h['url'],$cpsess);
		}

		$resArray = array();
		$resArray['statusCode'] = $statusCode;
		$resArray['message'] = $message;
		$resArray['cpanelId'] = (isset($cpsess[1])) ? $cpsess[1] : "";

		return $resArray;
	}

	function getAllDomainList($cpanelData){
		$cpanelId = $cpanelData['cpanelId'];
		$domainUrl = $cpanelData['cpanelLoginURL'];
		$cpanelUserName = $cpanelData['cpanelUserName'];
		$cpanelPassword = $cpanelData['cpanelPassword'];

		$headers = array(
		    'Authorization: Basic '. base64_encode($cpanelUserName.':'.$cpanelPassword),
		);
		
		$ch = curl_init($domainUrl.''.$cpanelId.'/execute/DomainInfo/domains_data');          
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);                                                            
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);                                                                
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);      

		$f = curl_exec($ch);
		curl_close($ch);
		
		$response = json_decode($f,true);
		if(!empty($response)){
			return $response; 
		}else{
			return array();
		}
	}

	function generatePriveteKey($cpanelData, $domainName){
		$friendlyName = 'pk_'.$domainName.'_'.date('YmdHis');
		$keytype = 'rsa-2048';

		$cpanelId = $cpanelData['cpanelId'];
		$domainUrl = $cpanelData['cpanelLoginURL'];
		$cpanelUserName = $cpanelData['cpanelUserName'];
		$cpanelPassword = $cpanelData['cpanelPassword'];

		$headers = array(
		    'Authorization: Basic '. base64_encode($cpanelUserName.':'.$cpanelPassword),
		);

		$ch = curl_init($domainUrl.''.$cpanelId.'/execute/SSL/generate_key?friendly_name='.$friendlyName.'&keytype='.$keytype);          
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);                                                            
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);                                                                
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);      

		$f = curl_exec($ch);
		curl_close($ch);
		
		$response = json_decode($f,true);
		if(!empty($response)){
			return $response; 
		}else{
			return array();
		}
	}

	function generateCSRForPriveteKey($cpanelData, $privateKeyID, $domainName, $isWildcard=""){
		$current_user = wp_get_current_user();
		if($isWildcard == 1){
			$userEmailAddress = 'admin@'.ltrim($domainName,"*.");
		}else{
			$userEmailAddress = 'admin@'.$domainName;
		}	

		$domains = $domainName;
		$countryName = 'US';
		$stateOrProvinceName = 'CA';
		$localityName = 'SACRAMENTO';
		$organizationName = 'SSL';
		$emailAddress = $userEmailAddress;

		$friendlyName = 'csr_'.$domainName.'_'.date('YmdHis');

		$cpanelId = $cpanelData['cpanelId'];
		$domainUrl = $cpanelData['cpanelLoginURL'];
		$cpanelUserName = $cpanelData['cpanelUserName'];
		$cpanelPassword = $cpanelData['cpanelPassword'];

		$headers = array(
		    'Authorization: Basic '. base64_encode($cpanelUserName.':'.$cpanelPassword),
		);

		$ch = curl_init($domainUrl.''.$cpanelId.'/execute/SSL/generate_csr?domains='.$domains.'&countryName='.$countryName.'&stateOrProvinceName='.$stateOrProvinceName.'&localityName='.$localityName.'&organizationName='.$organizationName.'&emailAddress='.$emailAddress.'&key_id='.$privateKeyID.'&friendly_name='.$friendlyName.'');          
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);                                                            
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);                                                                
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);      

		$f = curl_exec($ch);
		curl_close($ch);
		
		$response = json_decode($f,true);
		if(!empty($response)){
			return $response; 
		}else{
			return array();
		}
	}

	function saveFileContentOrUploadFile($cpanelData, $domain, $fileName, $fileContent){
		$cpanelId = $cpanelData['cpanelId'];
		$domainUrl = $cpanelData['cpanelLoginURL'];
		$cpanelUserName = $cpanelData['cpanelUserName'];
		$cpanelPassword = $cpanelData['cpanelPassword'];

		$rootPath = $cpanelData['rootPath'][$domain];
		$destination_dir = $rootPath.'/.well-known/pki-validation/';

		$payload = array(
	        'file' => $fileName,
	        'content' => $fileContent,
	        'dir' => $destination_dir,
	    );

	    $headers = array(
		    'Authorization: Basic '. base64_encode($cpanelUserName.':'.$cpanelPassword),
		);

	    $actionUrl = $domainUrl.''.$cpanelId.'/execute/Fileman/save_file_content';
	    $curl = curl_init();
	    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);       // Allow self-signed certs
	    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);       // Allow certs that do not match the hostname
	    curl_setopt($curl, CURLOPT_HEADER, 0);               // Do not include header in output
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);       // Return contents of transfer on curl_exec
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);    // set the username and password
	    curl_setopt($curl, CURLOPT_URL, $actionUrl);        // execute the query

	    // Set up a POST request with the payload.
	    curl_setopt($curl, CURLOPT_POST, true);
	    curl_setopt($curl, CURLOPT_POSTFIELDS, $payload);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

	    $result = curl_exec($curl);
	    curl_close($curl);
		return json_decode($result, true);
	}

	function installCertificateOnCpanel($cpanelData, $domain, $mainCert, $caBundle){
		$cpanelId = $cpanelData['cpanelId'];
		$domainUrl = $cpanelData['cpanelLoginURL'];
		$cpanelUserName = $cpanelData['cpanelUserName'];
		$cpanelPassword = $cpanelData['cpanelPassword'];

		$payload = array(
	        'domain' => $domain,
	        'cert' => $mainCert,
	        'key' => '',
	        'cabundle' => $caBundle,
	    );

	    $headers = array(
		    'Authorization: Basic '. base64_encode($cpanelUserName.':'.$cpanelPassword),
		);

	    $actionUrl = $domainUrl.''.$cpanelId.'/execute/SSL/install_ssl';
	    $curl = curl_init();
	    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);       // Allow self-signed certs
	    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);       // Allow certs that do not match the hostname
	    curl_setopt($curl, CURLOPT_HEADER, 0);               // Do not include header in output
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);       // Return contents of transfer on curl_exec
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);    // set the username and password
	    curl_setopt($curl, CURLOPT_URL, $actionUrl);        // execute the query

	    // Set up a POST request with the payload.
	    curl_setopt($curl, CURLOPT_POST, true);
	    curl_setopt($curl, CURLOPT_POSTFIELDS, $payload);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

	    $result = curl_exec($curl);
	    curl_close($curl);
		return json_decode($result, true);
	}

	function CreateCertificate($pin, $csr, $domainName, $approvalMethod="FILE", $approvalEmail=""){
		$payload = array(
	        'LicenseKey' => $pin,
	        'CSR' => $csr,
	        'DomainName' => $domainName,
	        'DCVMethod' => $approvalMethod,
	        'ApprovalEmail' => $approvalEmail,
	        'WebServerCode' => '28',
	        'WebServerName' => 'WHM/cPanel',
	        'UserAgent' => 'WPSSLPLUGIN',
	    );

	    $data_string = json_encode($payload);  
		$ch = curl_init(apiURL.'/CreateCertificate');                                                                  
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Accept: application/json','Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string))                                                                       
		);                                                                                                                   
		$result = curl_exec($ch);
		curl_close($ch);
		
		$json = json_decode($result, true);
		return $json;
	}

	function ReissueCertificate($pin, $csr, $domainName, $approvalMethod="FILE", $approvalEmail=""){
		$payload = array(
	        'LicenseKey' => $pin,
	        'CSR' => $csr,
	        'DomainName' => $domainName,
	        'DCVMethod' => $approvalMethod,
	        'ApprovalEmail' => $approvalEmail,
	    );

	    $data_string = json_encode($payload);  
		$ch = curl_init(apiURL.'/ReissueCertificate');                                                                  
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Accept: application/json','Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string))                                                                       
		);                                                                                                                   
		$result = curl_exec($ch);
		curl_close($ch);
		
		$json = json_decode($result, true);
		return $json;
	}

	function ValidateLicenseKey($pin){
		$payload = array(
	        'LicenseKey' => $pin,
	    );

	    $data_string = json_encode($payload);  
		$ch = curl_init(apiURL.'/ValidateLicenseKey');                                                                  
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Accept: application/json','Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string))                                                                       
		);                                                                                                                   
		$result = curl_exec($ch);
		curl_close($ch);
		
		$json = json_decode($result, true);
		return $json;
	}

	function GetCertificate($pin){
		$payload = array(
	        'LicenseKey' => $pin,
	    );

	    $data_string = json_encode($payload);  
		$ch = curl_init(apiURL.'/GetCertificate');                                                                  
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Accept: application/json','Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string))                                                                       
		);                                                                                                                   
		$result = curl_exec($ch);
		curl_close($ch);
		
		$json = json_decode($result, true);
		return $json;
	}

	function validateFileAccess($domainName, $fileName){
		$filePath = 'https://'.$domainName.'/.well-known/pki-validation/'.$fileName;
		$payload = array(
	        'FilePath' => $filePath,
	    );

	    $data_string = json_encode($payload);  
		$ch = curl_init(apiURL.'/ValidateFileAccess');                                                                  
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Accept: application/json','Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string))                                                                       
		);                                                                                                                   
		$result = curl_exec($ch);
		curl_close($ch);
		
		$json = json_decode($result, true);
		return $json;
	}

	function GetEmailApprovalList($domainName){
		$payload = array(
	        'DomainName' => $domainName,
	    );

	    $data_string = json_encode($payload);  
		$ch = curl_init(apiURL.'/GetEmailApprovalList');                                                                  
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Accept: application/json','Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string))                                                                       
		);                                                                                                                   
		$result = curl_exec($ch);
		curl_close($ch);
		
		$json = json_decode($result, true);
		return $json;
	}

	function ChangeDCVMethod($Pin,$DCVMethod,$ApprovalEmail=""){
		$payload = array(
	        'LicenseKey' => $Pin,
	        'DCVMethod' => $DCVMethod,
	        'ApprovalEmail' => $ApprovalEmail,
	    );

	    $data_string = json_encode($payload);  
		$ch = curl_init(apiURL.'/ChangeDCVMethod');                                                                  
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Accept: application/json','Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string))                                                                       
		);                                                                                                                   
		$result = curl_exec($ch);
		curl_close($ch);
		
		$json = json_decode($result, true);
		return $json;
	}

	function getRootDomainFromDomain($url){
		$pieces = parse_url($url);
		$domain = isset($pieces['host']) ? $pieces['host'] : $pieces['path'];
		
		if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
			return $regs['domain'];
		}
		return false;
	}
?>	