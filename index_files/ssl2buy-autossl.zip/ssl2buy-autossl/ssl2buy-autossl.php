<?php 
/*
Plugin Name: SSL2BUY AutoSSL Install 
Plugin URI: https://www.ssl2buy.com/
Description: Auto Install SSL Certificates on cpanel.
Version: 2.0
Author: SSL2BUY
Author URI: https://www.ssl2buy.com/
License: GPL
*/


function wpssl_activation(){
    global $wpdb;
	
	$wpsslTableName = $wpdb->prefix . 'wpssl';
	$wpsslSQL = "CREATE TABLE $wpsslTableName (
		    `id` INT(11) NOT NULL AUTO_INCREMENT ,
			`pin` VARCHAR(250) NOT NULL ,
			`status` VARCHAR(250) NOT NULL,
			`domainName` VARCHAR(250) NOT NULL,
			`expireOn` VARCHAR(250) NOT NULL ,
			`certificateId` VARCHAR(500) NOT NULL,
			`tempCertificateId` VARCHAR(500) NOT NULL,
			PRIMARY KEY  (`id`)
		);";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $wpsslSQL );
}

register_activation_hook(__FILE__, 'wpssl_activation');

add_action('admin_menu', 'wpSSLMenus');
function wpSSLMenus(){
	if ( current_user_can('administrator') ){
		add_menu_page('SSL2BUY AutoSSL','SSL2BUY AutoSSL', 0, 'wp-ssl', 'wp_ssl_callback', 'dashicons-lock');
		add_submenu_page('wp-ssl','SSL2BUY AutoSSL','SSL2BUY AutoSSL',0,'wp-ssl-add','wp_ssl_add_callback');
		add_submenu_page('wp-ssl','SSL2BUY AutoSSL','SSL2BUY AutoSSL',0,'wp-ssl-cpanel','wp_ssl_cpanel_callback');
	}
}

function wp_ssl_callback(){
	include 'autossl-list.php';
}

function wp_ssl_add_callback(){
	include 'autossl-pin-validate.php';
}

function wp_ssl_cpanel_callback(){
	include 'autossl-cpanel.php';
}

define( 'wpsslVersion', '2.0' );
define('apiURL', 'https://secure.configuressl.com/api/Tool');


function wpssl_head(){
    remove_submenu_page( 'wp-ssl', 'wp-ssl-add' );
    remove_submenu_page( 'wp-ssl', 'wp-ssl-cpanel' );
}
add_action( 'admin_head', 'wpssl_head' );

add_action( 'admin_init', 'wpssl_include_file' );
if ( ! function_exists( 'wpssl_include_file' ) ) {
	function wpssl_include_file() {
		wp_register_style('wp_ssl_style', plugins_url('css/style.css',__FILE__ ));
		wp_enqueue_style('wp_ssl_style');

		$lkey = ( isset($_GET['lkey']) && trim($_GET['lkey']) != '' ) ? trim($_GET['lkey']) : '';

		wp_enqueue_script('wp_ssl_js', plugins_url( 'js/autossl.js', __FILE__ ),array('jquery'), '1.0', true);  
        wp_localize_script('wp_ssl_js', 'ajax_vars', 
            array(  
            		'ajaxurl' => admin_url('admin-ajax.php'),
            		'lkey' => $lkey,
                )
        );

        include_once 'autossl-functions.php';
        include_once 'autossl-ajax-functions.php';

        if ( get_transient( 'wpssl_auto_install_transient' )) {
            delete_transient( 'wpssl_auto_install_transient' );
        }
	}
}

function wpssl_hide_notice_errors(){
    $adminPage = ( isset($_GET['page']) && trim($_GET['page']) != '' ) ? trim($_GET['page']) : '';
    if($adminPage == 'wp-ssl' || $adminPage == 'wp-ssl-add' || $adminPage == 'wp-ssl-cpanel'){
        remove_all_actions( 'admin_notices' );

        if(!function_exists('curl_version')){
        	add_action( 'admin_notices', 'wpssl_curl_notice' );
        }
    }    
}
add_action( 'admin_head', 'wpssl_hide_notice_errors', 1 );

function wpssl_curl_notice(){
	?>
		<h1 class="wp-ssl-logo"><img src="<?php echo plugins_url('images/ssl2buy-auto-ssl-logo.svg',__FILE__ ); ?>" alt="SSL2BUY Auto SSL" /></h1>
		<div class="notice notice-error is-dismissible" style="margin-left: 0;">
	      	<p>WP SSL required CURL extension. No CURL extention detected, please enable it.</p>
	    </div> 
    <?php
    die();
}

add_action('admin_init', 'wpssl_startsession', 1);
function wpssl_startsession(){
	if(!session_id()){
		session_start();
	}
}

function wpssl_logout( $user_id ) {
	$current_user   = get_user_by( 'id', $user_id );
    $role_name      = $current_user->roles[0];

    if($role_name == 'administrator'){
        wpssl_startsession();
        
        if(isset($_SESSION['cpanelData'])){
            unset($_SESSION['cpanelData']);
        }
    } 
}
add_action( 'wp_logout', 'wpssl_logout'  );

function wpssl_auto_install_plugin_info( $res, $action, $args ) {
    if ($action !== 'plugin_information') {
        return $res;
    }

    if( plugin_basename( __DIR__ ) !== $args->slug ) {
        return $res;
    }

    if (false == $remote = get_transient( 'wpssl_auto_install_transient' )) {
        $remote = wp_remote_get( 'https://www.ssl2buy.com/autossl-plugin/autossl.json', array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            ))
        );

        if (!is_wp_error( $remote ) && isset( $remote[ 'response' ][ 'code' ] ) && $remote[ 'response' ][ 'code' ] == 200 && !empty( $remote[ 'body' ] )) {
            set_transient( 'wpssl_auto_install_transient', $remote, 21600 );
        }
    }

    if (!is_wp_error( $remote )) {

        $remote = json_decode( $remote[ 'body' ] );

        $res = new stdClass();
        $res->name = $remote->name;
        $res->slug = $remote->slug;
        $res->version = $remote->version;
        $res->tested = $remote->tested;
        $res->requires = $remote->requires;
        $res->requires_php = $remote->requires_php;
        $res->author = $remote->author;
        $res->author_profile = $remote->author_profile;
        $res->download_link = $remote->download_url;
        $res->trunk = $remote->download_url;
        $res->last_updated = $remote->last_updated;
        $res->sections = array(
            'description' => $remote->sections->description, 
            'installation' => $remote->sections->installation,
            'changelog' => $remote->sections->changelog,
        );

        $res->banners = array(
            'low' => $remote->banners->low,
            'high' => $remote->banners->high,
        );

        return $res;
    }

    return false;
}
add_filter( 'plugins_api', 'wpssl_auto_install_plugin_info', 20, 3 );

function wpssl_auto_install_push_update( $transient ) {
	if (empty( $transient->checked )) {
        return $transient;
    }

    if (false == $remote = get_transient( 'wpssl_auto_install_transient' )) {
        $remote = wp_remote_get( 'https://www.ssl2buy.com/autossl-plugin/autossl.json', array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            ))
        );

        if (!is_wp_error( $remote ) && isset( $remote[ 'response' ][ 'code' ] ) && $remote[ 'response' ][ 'code' ] == 200 && !empty( $remote[ 'body' ] )) {
            set_transient( 'wpssl_auto_install_transient', $remote, 21600 );
        }
    }

    if (!is_wp_error( $remote )) {
        $remote = json_decode( $remote[ 'body' ] );

        if ($remote && version_compare( wpsslVersion, $remote->version, '<' )) {
            $res = new stdClass();
            $res->slug = $remote->slug;
            $res->plugin = 'ssl2buy-autossl/ssl2buy-autossl.php'; 
            $res->new_version = $remote->version;
            $res->tested = $remote->tested;
            $res->package = $remote->download_url;
            $transient->response[ $res->plugin ] = $res;
        }
    }
    return $transient;

}
add_filter( 'site_transient_update_plugins', 'wpssl_auto_install_push_update' );