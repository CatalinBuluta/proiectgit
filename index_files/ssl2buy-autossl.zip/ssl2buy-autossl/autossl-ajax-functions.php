<?php
add_action('wp_ajax_nopriv_wp_ssl_validate_pin', 'wp_ssl_validate_pin');
add_action('wp_ajax_wp_ssl_validate_pin', 'wp_ssl_validate_pin');
function wp_ssl_validate_pin(){
	$statusCode = 0;
	$isRedirect = 0;
	$errorMSG = '';
	$htmlContent = '';

	$pin = isset($_POST['pin']) ? trim($_POST['pin']) : '';
	if($pin != ''){
	    $pinData = getPinDetailFromLocalStorage($pin);
	    if(empty($pinData)){
	        $ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
	       	if($ValidateLicenseKeyResponse['StatusCode'] == 0){
				if( strtolower($ValidateLicenseKeyResponse['CertificateStatus']) == '' || strtolower($ValidateLicenseKeyResponse['CertificateStatus']) == 'completed'){
					$isRedirect = 1;
					$statusCode = 1;
				}else{
					$errorMSG = 'You have to configure this key on another tool, so please complete this process on that tool.';
				}
			}else{
				$errorMSG = $ValidateLicenseKeyResponse['ErrorDetail']['ErrorMessage'];	
			}
	    }else{
	    	$statusCode = 1;

	    	if(strtolower($pinData['status']) == 'complete'){
				$stausClass = 'status-complete';
			}else{
				$stausClass = 'status-awaiting-validation';
			}
	    	
	    	$htmlContent = '<div id="key-detail">';
		    	$htmlContent .= '<h2 style="margin-top: 0; display: inline-block;">License key <span>'.$pin.'</span></h2>';
				$htmlContent .= '<input type="button" id="changeKey" class="button button-primary button-large button-orange" value="Change Key">';
		    	$htmlContent .= '<div class="wp-ssl-table pin-detail">';
		    		$htmlContent .= '<table width="100%;" class="">';
		    			$htmlContent .= '<tr>';
		    				$htmlContent .= '<th>Domain Name</th>';
		    				$htmlContent .= '<th>Status</th>';
		    				$htmlContent .= '<th>Expire On</th>';
		    				$htmlContent .= '<th></th>';
		    			$htmlContent .= '</tr>';
		    			$htmlContent .= '<tr>';
		    				$htmlContent .= '<td>'.$pinData['domainName'].'</td>';
		    				$htmlContent .= '<td><span class="'.$stausClass.'">'.$pinData['status'].'</span></td>';
		    				$htmlContent .= '<td>'.$pinData['expireOn'].'</td>';
		    				if(strtolower($pinData['status']) == 'complete'){
		    					$htmlContent .= '<td style="text-align:right;"><a class="button button-primary button-large button-orange button-orange-sm" href="?page=wp-ssl-cpanel&lkey='.$pin.'">Reinstall</a></td>';
		    				}else{
		    					$htmlContent .= '<td style="text-align:right;"><a class="button button-primary button-large button-green button-green-sm" href="?page=wp-ssl-cpanel&lkey='.$pin.'">Install</a></td>';
		    				}
		    			$htmlContent .= '</tr>';
		    		$htmlContent .= '</table>';
		    	$htmlContent .= '</div>';
	    	$htmlContent .= '</div>';
	    }
	}else{
		$errorMSG = 'Please enter license key';
	}

	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['isRedirect'] = $isRedirect;
	$returnArray['errorMessage'] = $errorMSG;
	$returnArray['htmlContent'] = $htmlContent;
	
	echo json_encode($returnArray);
	die();
}

add_action('wp_ajax_nopriv_wp_ssl_validate_cpanel', 'wp_ssl_validate_cpanel');
add_action('wp_ajax_wp_ssl_validate_cpanel', 'wp_ssl_validate_cpanel');
function wp_ssl_validate_cpanel(){
	$statusCode = 0;
	$errorMSG = '';
	$htmlContent = '';

	$pin = isset($_POST['pin']) ? trim($_POST['pin']) : '';
	$cpanelLoginURL = isset($_POST['cpanelLoginURL']) ? trim($_POST['cpanelLoginURL']) : '';
	$cpanelUserName = isset($_POST['cpanelUserName']) ? trim($_POST['cpanelUserName']) : '';
	$cpanelPassword = isset($_POST['cpanelPassword']) ? trim($_POST['cpanelPassword']) : '';
	$cpanelPort = (isset($_POST['cpanelPort']) && trim($_POST['cpanelPort']) != '') ? trim($_POST['cpanelPort']) : '2083';

	if($cpanelLoginURL != '' && $cpanelUserName != '' && $cpanelPassword != ''){
		$sourceUrl = parse_url($cpanelLoginURL);
		$cpanelHost = isset($sourceUrl['host']) ? trim($sourceUrl['host']) : '';

		$cpanelLoginURL = 'https://'.$cpanelHost.':'.$cpanelPort;
		
		$loginCpanelResponse = loginCpanel($cpanelLoginURL, $cpanelUserName, $cpanelPassword);
		$loginStatusCode = $loginCpanelResponse['statusCode'];
		$loginMessage = $loginCpanelResponse['message'];
		$loginCpanelId = $loginCpanelResponse['cpanelId'];

		if($loginStatusCode == 1){
			if($loginCpanelId){
				$statusCode = 1;

				$_SESSION['cpanelData'][$pin]['cpanelId'] = $loginCpanelId;
				$_SESSION['cpanelData'][$pin]['cpanelLoginURL'] = $cpanelLoginURL;
				$_SESSION['cpanelData'][$pin]['cpanelUserName'] = $cpanelUserName;
				$_SESSION['cpanelData'][$pin]['cpanelPassword'] = $cpanelPassword;

				$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);

				$domainListArray = array();
				if(isset($_SESSION['cpanelData'][$pin]) && !empty($_SESSION['cpanelData'][$pin])){
					$domainList = getAllDomainList($_SESSION['cpanelData'][$pin]);
					if(isset($domainList['data']['main_domain']) && !empty($domainList['data']['main_domain'])){
						$dmName = $domainList['data']['main_domain']['domain'];
						$domainListArray[] = ($ValidateLicenseKeyResponse['IsWildcard'] == 1 ) ? '*.'.$dmName : $dmName;;

						$_SESSION['cpanelData'][$pin]['rootPath'][$dmName] =  $domainList['data']['main_domain']['documentroot'];
					}

					if(isset($domainList['data']['sub_domains']) && !empty($domainList['data']['sub_domains'])){
						foreach($domainList['data']['sub_domains'] as $subDomainItem){
							$dmName = $subDomainItem['domain'];
							$domainListArray[] = ($ValidateLicenseKeyResponse['IsWildcard'] == 1 ) ? '*.'.$dmName : $dmName;
							$_SESSION['cpanelData'][$pin]['rootPath'][$dmName] =  $subDomainItem['documentroot'];
						}	
					}

					if(isset($domainList['data']['addon_domains']) && !empty($domainList['data']['addon_domains'])){
						foreach($domainList['data']['addon_domains'] as $addonDomainItem){
							$dmName = $addonDomainItem['domain'];
							$domainListArray[] = ($ValidateLicenseKeyResponse['IsWildcard'] == 1 ) ? '*.'.$dmName : $dmName;
							$_SESSION['cpanelData'][$pin]['rootPath'][$dmName] =  $addonDomainItem['documentroot'];
						}	
					}
				}

				$isReissue = 0;
				$tempCertificateId = '';

				if( isset($ValidateLicenseKeyResponse['CAOrderNumber']) && $ValidateLicenseKeyResponse['CAOrderNumber'] != '' ){
					if( strtolower($ValidateLicenseKeyResponse['CertificateStatus']) == 'completed'){
						$isReissue = 1;

						$pinData = getPinDetailFromLocalStorage($pin);
						if(!empty($pinData)){
							$tempCertificateId = $pinData['tempCertificateId'];
						}
					}
				}

				$selectDisable = '';
				$cpanelValidDomain = true;
				if( trim($ValidateLicenseKeyResponse['DomainName']) != ''){
					$selectDisable = 'disabled';

					if(!in_array(trim($ValidateLicenseKeyResponse['DomainName']), $domainListArray)){
						$cpanelValidDomain = false;
					}
				}

				$htmlContent = '<div id="install-domain" class="domain-list-div">';
					$htmlContent .= '<h2 style="margin-top: 0; display: inline-block;">Select Domain Name</h2>';
					$htmlContent .= '<table width="100%;" class="login-table" role="presentation">';
						$htmlContent .= '<tbody>';
							$htmlContent .= '<tr>';
								$htmlContent .= '<td>';
									if($cpanelValidDomain) {
										$htmlContent .= '<select class="input-select" id="install-domain-name" name="domain" '.$selectDisable.'>';
											if( isset($ValidateLicenseKeyResponse['CAOrderNumber']) && $ValidateLicenseKeyResponse['CAOrderNumber'] != '' ){
												foreach($domainListArray as $dmnlist) {
													if( $ValidateLicenseKeyResponse['DomainName'] == $dmnlist ) {
														$htmlContent .= '<option value="'.$dmnlist.'">'.$dmnlist.'</option>';
													}
												}
											} else {
												foreach($domainListArray as $dmnlist) {
													$htmlContent .= '<option value="'.$dmnlist.'">'.$dmnlist.'</option>';
												}
											}		
										$htmlContent .= '</select>';
									}else{
										$htmlContent .= '<div class="ntc ntc-error"><p>'.$ValidateLicenseKeyResponse['DomainName'].' : domain name not found in cpanel account, so change cpanel account.</p></div>';
									}	
								$htmlContent .= '</td>';
							$htmlContent .= '</tr>';
							$htmlContent .= '<tr>';
								$htmlContent .= '<td>';	
									if($cpanelValidDomain) {
										if($isReissue == 1){
											if( $tempCertificateId != '' ){
												if($ValidateLicenseKeyResponse['DVCMethod'] == 'FILE'){
													$htmlContent .= '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Reinstall" class="button button-primary button-large button-orange">';
												} else {
													$htmlContent .= '<input type="button" id="continueProcess" name="tryAgainCert" value="Reinstall" class="button button-primary button-large button-orange">';
												}
											}else{
												$htmlContent .= '<input type="button" id="reissueCert" name="reissueCert" value="Reinstall" class="button button-primary button-large button-orange">';
											}
										}else{
											if( isset($ValidateLicenseKeyResponse['CAOrderNumber']) && $ValidateLicenseKeyResponse['CAOrderNumber'] != '' ){
												if($ValidateLicenseKeyResponse['DVCMethod'] == 'FILE'){
													$htmlContent .= '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Install" class="button button-primary button-large button-orange">';
												} else {
													$htmlContent .= '<input type="button" id="continueProcess" name="tryAgainCert" value="Install" class="button button-primary button-large button-orange">';
												}
											}else{
												$htmlContent .= '<input type="button" id="installCert" name="installCert" value="Install" class="button button-primary button-large button-orange">';

											}
										}
									}
									$htmlContent .= '<div class="change-cpanel">Don’t see the domain or website name you want to secure? <a href="javascript:void(0);" id="changeCpanel">click here</a> to change your cPanel account.</div>';		
								$htmlContent .= '</td>';
							$htmlContent .= '</tr>';
						$htmlContent .= '</tbody>';		
					$htmlContent .= '</table>';		
				$htmlContent .= '</div>';		
				
				if($cpanelValidDomain) {
					$btnText = '';
					if($isReissue == 1){
						if( $tempCertificateId != '' ){ 
					 		$stp1 = $stp2 = 'active'; 
					 		if($ValidateLicenseKeyResponse['DVCMethod'] == 'DNS'){
					 			$btnText = '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn" style="display:none;">';
					 			$btnText .= '<input type="button" id="checkdns" value="Check DNS" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
					 		}else{
					 			$btnText = '<input type="button" id="tryAgainReissueCert" name="reissueCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
					 		}

					 	} else { 
					 		$stp1 = $stp2 = '';
					 	}
					}else{
						if( isset($ValidateLicenseKeyResponse['CAOrderNumber']) && $ValidateLicenseKeyResponse['CAOrderNumber'] != '' ){
					 		$stp1 = $stp2 = 'active'; 
					 		if($ValidateLicenseKeyResponse['DVCMethod'] == 'DNS'){
					 			$btnText = '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn" style="display:none;">';
					 			$btnText .= '<input type="button" id="checkdns" value="Check DNS" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
					 		}else{
					 			$btnText = '<input type="button" id="tryAgainCert" name="tryAgainCert" value="Continue" class="button button-primary button-large button-orange btn-ctn ajax-btn">';
					 		}
					 	} else { 
					 		$stp1 = $stp2 = '';
					 	}
				 	}

				 	$dcvMethodText = '';
				 	if($stp1 == 'active'){
				 		if($ValidateLicenseKeyResponse['DVCMethod'] == 'EMAIL'){
				 			$approvalEmail = $ValidateLicenseKeyResponse['ApprovalEmail'];
				 			$dcvMethodText .= 'Please check <strong>'.$approvalEmail.'</strong> mailbox for an email received from Certificate Authority. That email contains all information to complete the verification process. If you have not received an email yet, please wait for a few minutes. 
Complete the email verification process and click on the CONTINUE button.';
				 		}else if($ValidateLicenseKeyResponse['DVCMethod'] == 'DNS'){
				 			$dcvMethodText .= nl2br($ValidateLicenseKeyResponse['DCVInfo']['DCVDNSContent']);
						}
				 	}

				 	$htmlContent .= '<div id="install-confirm-steps" class="confirm-step-div" style="display: none;">';	
				 		$htmlContent .= '<ul>';	
				 			$htmlContent .= '<li id="stp1" class="'.$stp1.'">Preparing Request</li>';	
				 			$htmlContent .= '<li id="stp2" class="'.$stp2.'">Requesting Certificate</li>';
				 			if($dcvMethodText){
				 				$htmlContent .= '<div class="notice-dcv"><p>'.$dcvMethodText.'</p></div>';
				 				$htmlContent .= $btnText;
				 			}	
				 			$htmlContent .= '<li id="stp3">Domain Verification</li>';	
				 			$htmlContent .= '<li id="stp4">Installing Certificate</li>';	
				 		$htmlContent .= '</ul>';	
				 		$htmlContent .= '<div class="alertmsg-while-process">';	
				 			$htmlContent .= 'Please do not close this window or refresh page or click the Back button on your browser while process is running.';	
				 		$htmlContent .= '</div>';	
				 	$htmlContent .= '</div>';	
				}
			}else{
				$errorMSG = 'Invalid login credentials OR cPanel URL';	
			}
		}else{
			$errorMSG = $loginMessage;	
		}
	}else{
		$errorMSG = 'Please enter all fields';
	}

	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['errorMessage'] = $errorMSG;
	$returnArray['htmlContent'] = $htmlContent;
	
	echo json_encode($returnArray);
	die();
}

add_action('wp_ajax_nopriv_wp_ssl_change_cpanel', 'wp_ssl_change_cpanel');
add_action('wp_ajax_wp_ssl_change_cpanel', 'wp_ssl_change_cpanel');
function wp_ssl_change_cpanel(){
	$htmlContent = '';
	$pin = isset($_POST['pin']) ? trim($_POST['pin']) : '';
	if(isset($_SESSION['cpanelData'][$pin])){
        unset($_SESSION['cpanelData'][$pin]);
    }

    $httpsHost = 'https';
	$cpnlUrl = $httpsHost.'://'.$_SERVER['SERVER_NAME'];

    $htmlContent = '<div id="cpanle-login-div">';
    	$htmlContent .= '<h2 style="margin-top: 0"><img src="'.plugins_url('images/cpanel-logo.svg',__FILE__ ).'" alt="cPanel" class="cpanel-logo" /></h2>';
		$htmlContent .= '<table width="100%;" class="login-table">';
			$htmlContent .= '<tbody>';
				$htmlContent .= '<tr>';
					$htmlContent .= '<td>';
						$htmlContent .= '<input type="text" class="text-input cpanel-url" id="cpanelLoginURL" name="cpanelLoginURL" autocomplete="off" value="'.$cpnlUrl.'" placeholder="cPanel URL (https://domain-name.com)">';
						$htmlContent .= '<input type="text" class="text-input cpanel-port" id="cpanelPort" name="cpanelPort" autocomplete="off" value="2083" placeholder="Port">';
					$htmlContent .= '</td>';
				$htmlContent .= '</tr>';
				$htmlContent .= '<tr>';
					$htmlContent .= '<td>';
						$htmlContent .= '<input type="text" class="text-input" id="cpanelUserName" name="cpanelUserName" autocomplete="off" placeholder="cPanel Username">';
					$htmlContent .= '</td>';
				$htmlContent .= '</tr>';
				$htmlContent .= '<tr>';
					$htmlContent .= '<td>';
						$htmlContent .= '<input type="password" class="text-input" id="cpanelPassword" name="cpanelPassword" autocomplete="off"  placeholder="cPanel Password">';
					$htmlContent .= '</td>';
				$htmlContent .= '</tr>';
				$htmlContent .= '<tr>';
					$htmlContent .= '<td>';
						$htmlContent .= '<input type="button" id="validateCpanel" name="validateCpanel" value="Next" class="button button-primary button-large button-orange">';
					$htmlContent .= '</td>';
				$htmlContent .= '</tr>';
			$htmlContent .= '</tbody>';
		$htmlContent .= '</table>';
    $htmlContent .= '</div>';

    $returnArray = array();
	$returnArray['htmlContent'] = $htmlContent;
	
	echo json_encode($returnArray);
	die();
}

add_action('wp_ajax_nopriv_wp_ssl_install_cert', 'wp_ssl_install_cert');
add_action('wp_ajax_wp_ssl_install_cert', 'wp_ssl_install_cert');
function wp_ssl_install_cert(){
	$selectedDomain = isset($_POST['domainName']) ? trim($_POST['domainName']) : '';
	$pin = isset($_POST['pin']) ? $_POST['pin'] : '';
	$approvalMethod = ( isset($_POST['approvalMethod']) && trim($_POST['approvalMethod']) != '') ? $_POST['approvalMethod'] : 'FILE';
	$approvalEmail = isset($_POST['approvalEmail']) ? $_POST['approvalEmail'] : '';

	$installMSG = '';
	$statusCode = 0;
	$pinStatus = 'pending';
	$pinOrderNumber = '';
	$wildcardDomainList = '';

	if($selectedDomain != ''){
		$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
		if($ValidateLicenseKeyResponse['StatusCode'] == 0){
			$privateKeyResponse = generatePriveteKey($_SESSION['cpanelData'][$pin], $selectedDomain);
			if(!empty($privateKeyResponse)){
				$privateKeyID = isset($privateKeyResponse['data']['id']) ? $privateKeyResponse['data']['id'] : '';
				if($privateKeyID){
					$csrResponse = generateCSRForPriveteKey($_SESSION['cpanelData'][$pin], $privateKeyID, $selectedDomain, $ValidateLicenseKeyResponse['IsWildcard']);
					$csrTextValue = isset($csrResponse['data']['text']) ? $csrResponse['data']['text'] : '';
					if($csrTextValue){
						echo 'stp1||';
						ob_flush();
						flush();

						sleep(1);
					
						if($approvalMethod == 'FILE'){
							$CreateCertificateResponse = CreateCertificate($pin, $csrTextValue, $selectedDomain,$approvalMethod, $approvalEmail);
							if($CreateCertificateResponse['StatusCode'] == 0){	
								$plcOrderNumber = $CreateCertificateResponse['CAOrderNumber']; 
								$certificateId = $CreateCertificateResponse['CACertificateId']; 
								
								$fileName = $CreateCertificateResponse['DCVInfo']['DCVFileName'];
								$fileContent = $CreateCertificateResponse['DCVInfo']['DCVFileContent'];

								insertDataInLocalStorage($pin, 'LINKPENDING');

								updatePinDateInLocalStorage($pin, 'AWAITING VALIDATION', $selectedDomain, $certificateId);

								$saveFileContentOrUploadFile = saveFileContentOrUploadFile($_SESSION['cpanelData'][$pin], $selectedDomain, $fileName, $fileContent);
								if(isset($saveFileContentOrUploadFile['status']) && $saveFileContentOrUploadFile['status'] == 1){
									
									$ChangeDCVMethod = ChangeDCVMethod($pin, $approvalMethod);
							
									echo 'stp2||';
									ob_flush();
									flush();

									sleep(5);

									$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
									if( strtolower($ValidateLicenseKeyResponse['CertificateStatus']) == 'completed'){
										$certInfo = GetCertificate($pin);
										if($certInfo['StatusCode'] == 0){	
											if(trim($certInfo['Certificate']) != ''){
												echo 'stp3||';
												ob_flush();
												flush();
												sleep(1);

												$mainCert = trim($certInfo['Certificate']);

												$caBundle = '';
												if( strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'alphassl' || strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'globalsign' ){
													if(isset($certInfo['IntermediateCertificate1']) && trim($certInfo['IntermediateCertificate1']) != ''){
														$caBundle .= trim($certInfo['IntermediateCertificate1'])."<br/>";
													}
													if(isset($certInfo['IntermediateCertificate2']) && trim($certInfo['IntermediateCertificate2']) != ''){
														$caBundle .= trim($certInfo['IntermediateCertificate2'])."<br/>";
													}
													if(isset($certInfo['RootCertificate']) && trim($certInfo['RootCertificate']) != ''){
														$caBundle .= trim($certInfo['RootCertificate'])."<br/>";
													}
												}else{
													if(isset($certInfo['RootCertificate']) && trim($certInfo['RootCertificate']) != ''){
														$caBundle .= trim($certInfo['RootCertificate'])."<br/>";
													}
													if(isset($certInfo['IntermediateCertificate1']) && trim($certInfo['IntermediateCertificate1']) != ''){
														$caBundle .= trim($certInfo['IntermediateCertificate1'])."<br/>";
													}
													if(isset($certInfo['IntermediateCertificate2']) && trim($certInfo['IntermediateCertificate2']) != ''){
														$caBundle .= trim($certInfo['IntermediateCertificate2'])."<br/>";
													}
												}
												
												$installCertResponse = installCertificateOnCpanel($_SESSION['cpanelData'][$pin], $selectedDomain, $mainCert, $caBundle);
												if($installCertResponse['status'] == 1){
													$certExpiryDate = date("m/d/Y", strtotime($certInfo['CertificateExpiryDate']));
													updatePinDateInLocalStorage($pin, 'COMPLETE', '','', $certExpiryDate);

													$installMSG = $installCertResponse['messages'][0];
													$statusCode = 1;
													unset($_SESSION['cpanelData'][$pin]);

													echo 'stp4||';
													ob_flush();
													flush();
												}else{
													$installMSG = $installCertResponse['errors'][0];
												}
											}else{
												$installMSG = 'Sometimes CA takes time to validate domain, so please try again.';	
											}
										}else{
											$installMSG = $certInfo['ErrorDetail']['ErrorMessage'];	
										}
									}else{
										$installMSG = 'Sometimes CA takes time to validate domain, so please try again.';
									}
								}else{
									$installMSG = 'Something went wrong while file upload.';	
								}
							}else{
								$installMSG = $CreateCertificateResponse['ErrorDetail']['ErrorMessage'];	
							}
						}else{
							$CreateCertificateResponse = CreateCertificate($pin, $csrTextValue, $selectedDomain,$approvalMethod, $approvalEmail);
							if($CreateCertificateResponse['StatusCode'] == 0){	
								$plcOrderNumber = $CreateCertificateResponse['CAOrderNumber']; 
								$certificateId = $CreateCertificateResponse['CACertificateId']; 
								insertDataInLocalStorage($pin, 'LINKPENDING');

								updatePinDateInLocalStorage($pin, 'AWAITING VALIDATION', $selectedDomain, $certificateId);
							
								$statusCode = 2;
								$dcvInfo = '';
								if($approvalMethod == 'EMAIL'){
									$installMSG = 'Please check <strong>'.$approvalEmail.'</strong> mailbox for an email received from Certificate Authority. That email contains all information to complete the verification process. If you have not received an email yet, please wait for a few minutes. Complete the email verification process and click on the CONTINUE button.';
								}else{
									$dnsString = nl2br($CreateCertificateResponse['DCVInfo']['DCVDNSContent']);
									$installMSG = $dnsString;

									$dcvInfo = '<div class="dcv-note"><span>Please create a valid DNS record as per the above details.</span>
                                                    1. Log into your domain’s hosting Control Panel (typically the registrar of your domain)<br/>
                                                    2. Locate and select the DNS Zone Manager for your desired domain. <br/>
                                                    3. Select the option to create a new record.</div>';
								}

								$wildcardDomainList .= $dcvInfo;
								if($ValidateLicenseKeyResponse['IsWildcard'] == 1){
									$domainNameStarWithout = ltrim($selectedDomain,'*');

									$domainListArray = array();
									$domainList = getAllDomainList($_SESSION['cpanelData'][$pin]);
									if(isset($domainList['data']['main_domain']) && !empty($domainList['data']['main_domain'])){
										$dmName = $domainList['data']['main_domain']['domain'];
										if(strpos($dmName, $domainNameStarWithout) !== false) {
											$domainListArray[] = $dmName;
										}
									}

									if(isset($domainList['data']['sub_domains']) && !empty($domainList['data']['sub_domains'])){
										foreach($domainList['data']['sub_domains'] as $subDomainItem){
											$dmName = $subDomainItem['domain'];
											if(strpos($dmName, $domainNameStarWithout) !== false) {
												$domainListArray[] = $dmName;
											}
										}	
									}

									if(isset($domainList['data']['addon_domains']) && !empty($domainList['data']['addon_domains'])){
										foreach($domainList['data']['addon_domains'] as $addonDomainItem){
											$dmName = $addonDomainItem['domain'];
											if(strpos($dmName, $domainNameStarWithout) !== false) {
												$domainListArray[] = $dmName;
											}
										}	
									}

									$mainDomain = ltrim($selectedDomain,'*.');
									$wildcardDomainList .= '<div class="wildcard-domain-list-div"><div class="wildcard-domain-list-title">Domains List</div>';
										$wildcardDomainList .= '<span><input type="checkbox" class="wildcardDomain" value="'.$mainDomain.'" checked disabled>&nbsp;'.$mainDomain.'</span>';
										if(!empty($domainListArray)){
											foreach($domainListArray as $dmnItem){
												$wildcardDomainList .= '<span><input type="checkbox" class="wildcardDomain" value="'.$dmnItem.'">&nbsp;'.$dmnItem.'</span>';
											}
										}
									$wildcardDomainList .= '</div>';
								}

								echo 'stp2||';
								ob_flush();
								flush();
							}else{
								$installMSG = $CreateCertificateResponse['ErrorDetail']['ErrorMessage'];	
							}
						}	
					}else{
						$installMSG = 'Something went wrong while generating CSR.';
					}
				}else{
					$installMSG = 'Something went wrong while generating key pair.';
				}
			}else{
				$installMSG = 'Something went wrong while generating key pair.';
			}

			$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
			if($ValidateLicenseKeyResponse['StatusCode'] == 0){
				$pinOrderNumber = $ValidateLicenseKeyResponse['CAOrderNumber'];
			}
		}else{
			$installMSG = $ValidateLicenseKeyResponse['ErrorDetail']['ErrorMessage'];	
		}
	}else{
		$installMSG = 'Please select domain';	
	}

	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['message'] = $installMSG;
	$returnArray['pinOrderNumber'] = $pinOrderNumber;
	$returnArray['wildcardDomainList'] = $wildcardDomainList;
	
	echo json_encode($returnArray);
	die();
}

add_action('wp_ajax_nopriv_wp_ssl_install_try_cert', 'wp_ssl_install_try_cert');
add_action('wp_ajax_wp_ssl_install_try_cert', 'wp_ssl_install_try_cert');
function wp_ssl_install_try_cert(){
	$selectedDomain = isset($_POST['domainName']) ? trim($_POST['domainName']) : '';
	$approvalMethod = ( isset($_POST['approvalMethod']) && trim($_POST['approvalMethod']) != '') ? $_POST['approvalMethod'] : 'FILE';
	$pin = isset($_POST['pin']) ? $_POST['pin'] : '';

	$wildcardDomainList = isset($_POST['wildcardDomainList']) ? rtrim($_POST['wildcardDomainList'],'||') : '';

	$installMSG = '';
	$statusCode = 0;
	$pinOrderNumber = '';

	if($selectedDomain != ''){
		$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
		if($ValidateLicenseKeyResponse['StatusCode'] == 0){
			$approvalMethod = $ValidateLicenseKeyResponse['DVCMethod'];

			if($approvalMethod == 'DNS' || $approvalMethod == 'FILE' ){
				$ChangeDCVMethod = ChangeDCVMethod($pin, $approvalMethod);
			}

			if( strtolower($ValidateLicenseKeyResponse['CertificateStatus']) == 'completed'){
				$certInfo = GetCertificate($pin);
				if($certInfo['StatusCode'] == 0){
					if(trim($certInfo['Certificate']) != ''){	
						echo 'stp3||';
						ob_flush();
						flush();
						sleep(1);

						$mainCert = trim($certInfo['Certificate']);

						$caBundle = '';
						if( strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'alphassl' || strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'globalsign' ){
							if(isset($certInfo['IntermediateCertificate1']) && trim($certInfo['IntermediateCertificate1']) != ''){
								$caBundle .= trim($certInfo['IntermediateCertificate1'])."<br/>";
							}
							if(isset($certInfo['IntermediateCertificate2']) && trim($certInfo['IntermediateCertificate2']) != ''){
								$caBundle .= trim($certInfo['IntermediateCertificate2'])."<br/>";
							}
							if(isset($certInfo['RootCertificate']) && trim($certInfo['RootCertificate']) != ''){
								$caBundle .= trim($certInfo['RootCertificate'])."<br/>";
							}
						}else{
							if(isset($certInfo['RootCertificate']) && trim($certInfo['RootCertificate']) != ''){
								$caBundle .= trim($certInfo['RootCertificate'])."<br/>";
							}
							if(isset($certInfo['IntermediateCertificate1']) && trim($certInfo['IntermediateCertificate1']) != ''){
								$caBundle .= trim($certInfo['IntermediateCertificate1'])."<br/>";
							}
							if(isset($certInfo['IntermediateCertificate2']) && trim($certInfo['IntermediateCertificate2']) != ''){
								$caBundle .= trim($certInfo['IntermediateCertificate2'])."<br/>";
							}
						}
						
						if( $ValidateLicenseKeyResponse['IsWildcard'] == 1 ){
							$domainNameWithoutStar = ltrim($selectedDomain,"*.");
						}else{
							$domainNameWithoutStar = $selectedDomain;
						}

						if($wildcardDomainList != ''){
							$wildcardDomainArray = explode('||', $wildcardDomainList);
							foreach($wildcardDomainArray as $wildDmn){
								$installCertResponse = installCertificateOnCpanel($_SESSION['cpanelData'][$pin], $wildDmn, $mainCert, $caBundle);
								if($installCertResponse['status'] == 1){
									$installMSG .= $installCertResponse['messages'][0]."<br/>";
									$statusCode = 1;
								}else{
									$installMSG .= $wildDmn.' not installed<br/>';
								}
							}

							$certExpiryDate = date("m/d/Y", strtotime($certInfo['CertificateExpiryDate']));

							updatePinDateInLocalStorage($pin, 'COMPLETE', '','', $certExpiryDate);
							unset($_SESSION['cpanelData'][$pin]);

							echo 'stp4||';
							ob_flush();
							flush();
						}else{
							$installCertResponse = installCertificateOnCpanel($_SESSION['cpanelData'][$pin], $domainNameWithoutStar, $mainCert, $caBundle);
							if($installCertResponse['status'] == 1){
								echo 'stp4||';
								ob_flush();
								flush();
								
								$certExpiryDate = date("m/d/Y", strtotime($certInfo['CertificateExpiryDate']));

								updatePinDateInLocalStorage($pin, 'COMPLETE', '','', $certExpiryDate);
								$statusCode = 1;
								$installMSG = $installCertResponse['messages'][0];
								unset($_SESSION['cpanelData'][$pin]);
							}else{
								$installMSG = $installCertResponse['errors'][0];
							}
						}
					}else{
						$installMSG = 'Sometimes CA takes time to validate domain, so please try again.';
					}
				}else{
					$installMSG = $certInfo['ErrorDetail']['ErrorMessage'];	
				}
			}else{
				$installMSG = 'Sometimes CA takes time to validate domain, so please try again.';
			}
			
			$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
			if($ValidateLicenseKeyResponse['StatusCode'] == 0){
				$pinOrderNumber = $ValidateLicenseKeyResponse['CAOrderNumber'];
			}
		}else{
			$installMSG = $ValidateLicenseKeyResponse['ErrorDetail']['ErrorMessage'];	
		}
	}else{
		$installMSG = 'Please select domain';	
	}

	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['message'] = $installMSG;
	$returnArray['pinOrderNumber'] = $pinOrderNumber;
	
	echo json_encode($returnArray);
	die();
}


add_action('wp_ajax_nopriv_wp_ssl_reissue_cert', 'wp_ssl_reissue_cert');
add_action('wp_ajax_wp_ssl_reissue_cert', 'wp_ssl_reissue_cert');
function wp_ssl_reissue_cert(){
	$selectedDomain = isset($_POST['domainName']) ? trim($_POST['domainName']) : '';
	$pin = isset($_POST['pin']) ? $_POST['pin'] : '';
	$approvalMethod = ( isset($_POST['approvalMethod']) && trim($_POST['approvalMethod']) != '') ? $_POST['approvalMethod'] : 'FILE';
	$approvalEmail = isset($_POST['approvalEmail']) ? $_POST['approvalEmail'] : '';

	$reissueMSG = '';
	$statusCode = 0;
	$tempCertificateId = '';
	$wildcardDomainList = '';

	if($selectedDomain != ''){
		$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
		if($ValidateLicenseKeyResponse['StatusCode'] == 0){
			$privateKeyResponse = generatePriveteKey($_SESSION['cpanelData'][$pin], $selectedDomain);
			if(!empty($privateKeyResponse)){
				$privateKeyID = isset($privateKeyResponse['data']['id']) ? $privateKeyResponse['data']['id'] : '';
				if($privateKeyID){
					$csrResponse = generateCSRForPriveteKey($_SESSION['cpanelData'][$pin], $privateKeyID, $selectedDomain, $ValidateLicenseKeyResponse['IsWildcard']);
					$csrTextValue = isset($csrResponse['data']['text']) ? $csrResponse['data']['text'] : '';
					if($csrTextValue){
						echo 'stp1||';
						ob_flush();
						flush();
						sleep(1);
						
						if($approvalMethod == 'FILE'){
							$ReissueCertificateResponse = ReissueCertificate($pin, $csrTextValue, $selectedDomain);
							if($ReissueCertificateResponse['StatusCode'] == 0){
								$riseCertificateId = $ReissueCertificateResponse['CACertificateId']; 
								
								$fileName = $ReissueCertificateResponse['DCVInfo']['DCVFileName'];
								$fileContent = $ReissueCertificateResponse['DCVInfo']['DCVFileContent'];

								insertDataInLocalStorage($pin, 'LINKPENDING');

								updatePinDateInLocalStorage($pin, '', $selectedDomain, $riseCertificateId, '',$riseCertificateId);
								
								$saveFileContentOrUploadFile = saveFileContentOrUploadFile($_SESSION['cpanelData'][$pin], $selectedDomain, $fileName, $fileContent);
								if(isset($saveFileContentOrUploadFile['status']) && $saveFileContentOrUploadFile['status'] == 1){
									
									$ChangeDCVMethod = ChangeDCVMethod($pin, $approvalMethod);

									echo 'stp2||';
									ob_flush();
									flush();
									sleep(5);

									$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
									if( strtolower($ValidateLicenseKeyResponse['CertificateStatus']) == 'completed'){
										$certInfo = GetCertificate($pin);
										if($certInfo['StatusCode'] == 0){
											if(trim($certInfo['Certificate']) != ''){
												echo 'stp3||';
												ob_flush();
												flush();
												sleep(1);

												$mainCert = trim($certInfo['Certificate']);

												$caBundle = '';
												if( strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'alphassl' || strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'globalsign' ){
													if(isset($certInfo['IntermediateCertificate1']) && trim($certInfo['IntermediateCertificate1']) != ''){
														$caBundle .= trim($certInfo['IntermediateCertificate1'])."<br/>";
													}
													if(isset($certInfo['IntermediateCertificate2']) && trim($certInfo['IntermediateCertificate2']) != ''){
														$caBundle .= trim($certInfo['IntermediateCertificate2'])."<br/>";
													}
													if(isset($certInfo['RootCertificate']) && trim($certInfo['RootCertificate']) != ''){
														$caBundle .= trim($certInfo['RootCertificate'])."<br/>";
													}
												}else{
													if(isset($certInfo['RootCertificate']) && trim($certInfo['RootCertificate']) != ''){
														$caBundle .= trim($certInfo['RootCertificate'])."<br/>";
													}
													if(isset($certInfo['IntermediateCertificate1']) && trim($certInfo['IntermediateCertificate1']) != ''){
														$caBundle .= trim($certInfo['IntermediateCertificate1'])."<br/>";
													}
													if(isset($certInfo['IntermediateCertificate2']) && trim($certInfo['IntermediateCertificate2']) != ''){
														$caBundle .= trim($certInfo['IntermediateCertificate2'])."<br/>";
													}
												}
												
												$installCertResponse = installCertificateOnCpanel($_SESSION['cpanelData'][$pin], $selectedDomain, $mainCert, $caBundle);
												if($installCertResponse['status'] == 1){
													$certExpiryDate = date("m/d/Y", strtotime($certInfo['CertificateExpiryDate']));
													updatePinDateInLocalStorage($pin, 'COMPLETE', '','', $certExpiryDate,'', 1);

													$reissueMSG = $installCertResponse['messages'][0];
													$statusCode = 1;
													unset($_SESSION['cpanelData'][$pin]);

													echo 'stp4||';
													ob_flush();
													flush();
												}else{
													$reissueMSG = $installCertResponse['errors'][0];
												}
											}else{
												$reissueMSG = 'Sometimes CA takes time to validate domain, so please try again.';			
											}
										}else{
											$reissueMSG = $certInfo['ErrorDetail']['ErrorMessage'];		
										}
									}else{
										$reissueMSG = 'Sometimes CA takes time to validate domain, so please try again.';
									}
								}else{
									$reissueMSG = 'Something went wrong while file upload.';	
								}
							}else{
								$reissueMSG = $ReissueCertificateResponse['ErrorDetail']['ErrorMessage'];	
							}
						}else{
							$ReissueCertificateResponse = ReissueCertificate($pin, $csrTextValue, $selectedDomain,$approvalMethod, $approvalEmail);
							if($ReissueCertificateResponse['StatusCode'] == 0){
								$riseCertificateId = $ReissueCertificateResponse['CACertificateId']; 

								insertDataInLocalStorage($pin, 'LINKPENDING');
								updatePinDateInLocalStorage($pin, '', $selectedDomain, $riseCertificateId,'',$riseCertificateId);

								$statusCode = 2;
								$dcvInfo = '';
								if($approvalMethod == 'EMAIL'){
									$reissueMSG = 'Please check <strong>'.$approvalEmail.'</strong> mailbox for an email received from Certificate Authority. That email contains all information to complete the verification process. If you have not received an email yet, please wait for a few minutes. 
Complete the email verification process and click on the CONTINUE button.';
								}else{
									$dnsString = nl2br($ReissueCertificateResponse['DCVInfo']['DCVDNSContent']);
									$reissueMSG = $dnsString;

									$dcvInfo = '<div class="dcv-note"><span>Please create a valid DNS record as per the above details.</span>
                                                    1. Log into your domain’s hosting Control Panel (typically the registrar of your domain)<br/>
                                                    2. Locate and select the DNS Zone Manager for your desired domain. <br/>
                                                    3. Select the option to create a new record.</div>';
								}

								$wildcardDomainList .= $dcvInfo;
								if($ValidateLicenseKeyResponse['IsWildcard'] == 1){
									$domainNameStarWithout = ltrim($selectedDomain,'*');

									$domainListArray = array();
									$domainList = getAllDomainList($_SESSION['cpanelData'][$pin]);
									if(isset($domainList['data']['main_domain']) && !empty($domainList['data']['main_domain'])){
										$dmName = $domainList['data']['main_domain']['domain'];
										if(strpos($dmName, $domainNameStarWithout) !== false) {
											$domainListArray[] = $dmName;
										}
									}

									if(isset($domainList['data']['sub_domains']) && !empty($domainList['data']['sub_domains'])){
										foreach($domainList['data']['sub_domains'] as $subDomainItem){
											$dmName = $subDomainItem['domain'];
											if(strpos($dmName, $domainNameStarWithout) !== false) {
												$domainListArray[] = $dmName;
											}
										}	
									}

									if(isset($domainList['data']['addon_domains']) && !empty($domainList['data']['addon_domains'])){
										foreach($domainList['data']['addon_domains'] as $addonDomainItem){
											$dmName = $addonDomainItem['domain'];
											if(strpos($dmName, $domainNameStarWithout) !== false) {
												$domainListArray[] = $dmName;
											}
										}	
									}

									$mainDomain = ltrim($selectedDomain,'*.');
									$wildcardDomainList .= '<div class="wildcard-domain-list-div"><div class="wildcard-domain-list-title">Domains List</div>';
										$wildcardDomainList .= '<span><input type="checkbox" class="wildcardDomain" value="'.$mainDomain.'" checked disabled>&nbsp;'.$mainDomain.'</span>';
										if(!empty($domainListArray)){
											foreach($domainListArray as $dmnItem){
												$wildcardDomainList .= '<span><input type="checkbox" class="wildcardDomain" value="'.$dmnItem.'">&nbsp;'.$dmnItem.'</span>';
											}
										}
									$wildcardDomainList .= '</div>';
								}

								echo 'stp2||';
								ob_flush();
								flush();
							}else{
								$reissueMSG = $ReissueCertificateResponse['ErrorDetail']['ErrorMessage'];	
							}
						}	
					}else{
						$reissueMSG = 'Something went wrong while generating CSR.';
					}
				}else{
					$reissueMSG = 'Something went wrong while generating key pair.';
				}
			}else{
				$reissueMSG = 'Something went wrong while generating key pair.';
			}

			$pinData = getPinDetailFromLocalStorage($pin);
			if(!empty($pinData)){
				$tempCertificateId = $pinData['tempCertificateId'];
			}
		}else{
			$reissueMSG = $ValidateLicenseKeyResponse['ErrorDetail']['ErrorMessage'];
		}
	}else{
		$reissueMSG = 'Please select domain';	
	}

	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['message'] = $reissueMSG;
	$returnArray['tempCertificateId'] = $tempCertificateId;
	$returnArray['wildcardDomainList'] = $wildcardDomainList;
	
	echo json_encode($returnArray);
	die();
}

add_action('wp_ajax_nopriv_wp_ssl_reissue_try_cert', 'wp_ssl_reissue_try_cert');
add_action('wp_ajax_wp_ssl_reissue_try_cert', 'wp_ssl_reissue_try_cert');
function wp_ssl_reissue_try_cert(){
	$selectedDomain = isset($_POST['domainName']) ? trim($_POST['domainName']) : '';
	$pin = isset($_POST['pin']) ? $_POST['pin'] : '';
	$approvalMethod = ( isset($_POST['approvalMethod']) && trim($_POST['approvalMethod']) != '') ? $_POST['approvalMethod'] : 'FILE';

	$wildcardDomainList = isset($_POST['wildcardDomainList']) ? rtrim($_POST['wildcardDomainList'],'||') : '';

	$reissueMSG = '';
	$statusCode = 0;
	$tempCertificateId = '';

	if($selectedDomain != ''){
		$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
		if($ValidateLicenseKeyResponse['StatusCode'] == 0){
			$approvalMethod = $ValidateLicenseKeyResponse['DVCMethod'];

			if($approvalMethod == 'DNS' || $approvalMethod == 'FILE' ){	
				$ChangeDCVMethod = ChangeDCVMethod($pin, $approvalMethod);
			}

			if( strtolower($ValidateLicenseKeyResponse['CertificateStatus']) == 'completed'){
				$certInfo = GetCertificate($pin);
				if($certInfo['StatusCode'] == 0){
					if(trim($certInfo['Certificate']) != ''){
						echo 'stp3||';
						ob_flush();
						flush();
						sleep(1);

						$mainCert = trim($certInfo['Certificate']);

						$caBundle = '';
						if( strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'alphassl' || strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'globalsign' ){
							if(isset($certInfo['IntermediateCertificate1']) && trim($certInfo['IntermediateCertificate1']) != ''){
								$caBundle .= trim($certInfo['IntermediateCertificate1'])."<br/>";
							}
							if(isset($certInfo['IntermediateCertificate2']) && trim($certInfo['IntermediateCertificate2']) != ''){
								$caBundle .= trim($certInfo['IntermediateCertificate2'])."<br/>";
							}
							if(isset($certInfo['RootCertificate']) && trim($certInfo['RootCertificate']) != ''){
								$caBundle .= trim($certInfo['RootCertificate'])."<br/>";
							}
						}else{
							if(isset($certInfo['RootCertificate']) && trim($certInfo['RootCertificate']) != ''){
								$caBundle .= trim($certInfo['RootCertificate'])."<br/>";
							}
							if(isset($certInfo['IntermediateCertificate1']) && trim($certInfo['IntermediateCertificate1']) != ''){
								$caBundle .= trim($certInfo['IntermediateCertificate1'])."<br/>";
							}
							if(isset($certInfo['IntermediateCertificate2']) && trim($certInfo['IntermediateCertificate2']) != ''){
								$caBundle .= trim($certInfo['IntermediateCertificate2'])."<br/>";
							}
						}
						
						if( $ValidateLicenseKeyResponse['IsWildcard'] == 1 ){
							$domainNameWithoutStar = ltrim($selectedDomain,"*.");
						}else{
							$domainNameWithoutStar = $selectedDomain;
						}

						if($wildcardDomainList != ''){
							$wildcardDomainArray = explode('||', $wildcardDomainList);
							foreach($wildcardDomainArray as $wildDmn){
								$installCertResponse = installCertificateOnCpanel($_SESSION['cpanelData'][$pin], $wildDmn, $mainCert, $caBundle);
								if($installCertResponse['status'] == 1){
									$reissueMSG .= $installCertResponse['messages'][0]."<br/>";
									$statusCode = 1;
								}else{
									$reissueMSG .= $wildDmn.' not installed<br/>';
								}
							}

							$certExpiryDate = date("m/d/Y", strtotime($certInfo['CertificateExpiryDate']));
							updatePinDateInLocalStorage($pin, 'COMPLETE', '','', $certExpiryDate,'', 1);
							unset($_SESSION['cpanelData'][$pin]);

							echo 'stp4||';
							ob_flush();
							flush();
						}else{
							$installCertResponse = installCertificateOnCpanel($_SESSION['cpanelData'][$pin], $domainNameWithoutStar, $mainCert, $caBundle);
							if($installCertResponse['status'] == 1){
								$certExpiryDate = date("m/d/Y", strtotime($certInfo['CertificateExpiryDate']));
								updatePinDateInLocalStorage($pin, 'COMPLETE', '','', $certExpiryDate,'', 1);

								$statusCode = 1;
								$reissueMSG = $installCertResponse['messages'][0];
								unset($_SESSION['cpanelData'][$pin]);

								echo 'stp4||';
								ob_flush();
								flush();
							}else{
								$reissueMSG = $installCertResponse['errors'][0];
							}
						}
					}else{
						$reissueMSG = 'Sometimes CA takes time to validate domain, so please try again.';		
					}
				}else{
					$reissueMSG = $certInfo['ErrorDetail']['ErrorMessage'];	
				}
			}else{
				$reissueMSG = 'Sometimes CA takes time to validate domain, so please try again.';
			}

			$pinData = getPinDetailFromLocalStorage($pin);
			if(!empty($pinData)){
				$tempCertificateId = $pinData['tempCertificateId'];
			}
		}else{
			$reissueMSG = $ValidateLicenseKeyResponse['ErrorDetail']['ErrorMessage'];	
		}
	}else{
		$reissueMSG = 'Please select domain';	
	}

	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['message'] = $reissueMSG;
	$returnArray['tempCertificateId'] = $tempCertificateId;
	
	echo json_encode($returnArray);
	die();
}

add_action('wp_ajax_nopriv_wp_ssl_check_domain_public_access', 'wp_ssl_check_domain_public_access');
add_action('wp_ajax_wp_ssl_check_domain_public_access', 'wp_ssl_check_domain_public_access');
function wp_ssl_check_domain_public_access(){
	$fileName = 'sample.txt';
	$statusCode = 0;
	$htmlContent = '';

	$pin = isset($_POST['pin']) ? $_POST['pin'] : '';
	$selectedDomain = isset($_POST['domainName']) ? trim($_POST['domainName']) : '';
	$reissue = isset($_POST['reissue']) ? trim($_POST['reissue']) : 0;
	
	$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
	if($ValidateLicenseKeyResponse['IsWildcard'] == 1 ){
		$validateFileAccess['StatusCode'] = -1;
	}else{
		$saveFileContentOrUploadFile = saveFileContentOrUploadFile($_SESSION['cpanelData'][$pin], $selectedDomain, $fileName, $selectedDomain);

		$validateFileAccess = validateFileAccess($selectedDomain, $fileName);
	}

	if($validateFileAccess['StatusCode'] == 0){
		$statusCode = 1;
	}else{
		if($reissue == 1){
			$htmlContent .= '<div id="reissue-domain-approval-list" class="domain-approval-list">';
				$htmlContent .= '<h2 style="margin-top: 0;">Select Domain Approval Method</h2>';
				if( strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'alphassl' || strtolower($ValidateLicenseKeyResponse['CompanyName']) == 'globalsign' ){
					if( $ValidateLicenseKeyResponse['DVCMethod'] == 'EMAIL' ){
						$htmlContent .= '<div class="domain-approval-item">';
							$htmlContent .= '<div class="domain-approval-item-left"><h3>EMAIL</h3><p>Please check this option to select active email address from the list and click on Continue button.</br>
								An email will be delivered to the selected email address. That email will have all the required information to complete the process.</p></div>';
							$htmlContent .= '<div class="domain-approval-item-right"><input type="radio" id="dcvmethod-email" name="approval-method" class="reissue-select-approval-method" value="EMAIL"><label for="dcvmethod-email"></label></div>';
						$htmlContent .= '</div>';
					}

					if( $ValidateLicenseKeyResponse['DVCMethod'] == 'DNS' ){
						$htmlContent .= '<div class="domain-approval-item">';
							$htmlContent .= '<div class="domain-approval-item-left"><h3>DNS</h3><p>You will get DNS record value on next step.
							</br>
							You have to create a specific DNS record on right place - Domain Registrar or Hosting Control Panel.</p></div>';
							$htmlContent .= '<div class="domain-approval-item-right"><input type="radio" id="dcvmethod-dns" name="approval-method" class="reissue-select-approval-method" value="DNS"><label for="dcvmethod-dns"></label></div>';
						$htmlContent .= '</div>';
					}
				}else{
					$htmlContent .= '<div class="domain-approval-item">';
						$htmlContent .= '<div class="domain-approval-item-left"><h3>EMAIL</h3><p>Please check this option to select active email address from the list and click on Continue button.</br>
							An email will be delivered to the selected email address. That email will have all the required information to complete the process.</p></div>';
						$htmlContent .= '<div class="domain-approval-item-right"><input type="radio" id="dcvmethod-email" name="approval-method" class="reissue-select-approval-method" value="EMAIL"><label for="dcvmethod-email"></label></div>';
					$htmlContent .= '</div>';

					$htmlContent .= '<div class="domain-approval-item">';
						$htmlContent .= '<div class="domain-approval-item-left"><h3>DNS</h3><p>You will get DNS record value on next step.
						</br>
						You have to create a specific DNS record on right place - Domain Registrar or Hosting Control Panel.</p></div>';
						$htmlContent .= '<div class="domain-approval-item-right"><input type="radio" id="dcvmethod-dns" name="approval-method" class="reissue-select-approval-method" value="DNS"><label for="dcvmethod-dns"></label></div>';
					$htmlContent .= '</div>';
				}
			$htmlContent .= '</div>';	
		}else{
			$htmlContent .= '<div id="domain-approval-list" class="domain-approval-list">';
				$htmlContent .= '<h2 style="margin-top: 0;">Select Domain Approval Method</h2>';

				$htmlContent .= '<div class="domain-approval-item">';
					$htmlContent .= '<div class="domain-approval-item-left"><h3>EMAIL</h3><p>Please check this option to select active email address from the list and click on Continue button.</br>
						An email will be delivered to the selected email address. That email will have all the required information to complete the process.</p></div>';
					$htmlContent .= '<div class="domain-approval-item-right"><input type="radio" id="dcvmethod-email" name="approval-method" class="select-approval-method" value="EMAIL"><label for="dcvmethod-email"></label></div>';
				$htmlContent .= '</div>';

				$htmlContent .= '<div class="domain-approval-item">';
					$htmlContent .= '<div class="domain-approval-item-left"><h3>DNS</h3><p>You will get DNS record value on next step.
					</br>
					You have to create a specific DNS record on right place - Domain Registrar or Hosting Control Panel.</p></div>';
					$htmlContent .= '<div class="domain-approval-item-right"><input type="radio" id="dcvmethod-dns" name="approval-method" class="select-approval-method" value="DNS"><label for="dcvmethod-dns"></label></div>';
				$htmlContent .= '</div>';
			$htmlContent .= '</div>';	
		}
	}
	
	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['htmlContent'] = $htmlContent;
	
	echo json_encode($returnArray);
	die();
}

add_action('wp_ajax_nopriv_wp_ssl_get_apporval_email_list', 'wp_ssl_get_apporval_email_list');
add_action('wp_ajax_wp_ssl_get_apporval_email_list', 'wp_ssl_get_apporval_email_list');
function wp_ssl_get_apporval_email_list(){
	$statusCode = 0;
	$htmlContent = '';

	$selectedDomain = isset($_POST['domainName']) ? trim($_POST['domainName']) : '';
	$GetEmailApprovalList = GetEmailApprovalList($selectedDomain);
	if($GetEmailApprovalList['StatusCode'] == 0){
		$statusCode = 1;

		if( isset($GetEmailApprovalList['ApprovalEmailList']) && !empty($GetEmailApprovalList['ApprovalEmailList']) ){
			$htmlContent .= '<div id="domain-approval-email-list-div" class="domain-approval-email-list-div">';
				$htmlContent .= '<select class="input-select" id="domain-approval-email-list" name="domain-approval-email-list">';
					$htmlContent .= '<option value="">---Select Approval Email---</option>';
					foreach($GetEmailApprovalList['ApprovalEmailList'] as $approvalEmailList){
						$htmlContent .= '<option value="'.$approvalEmailList.'">'.$approvalEmailList.'</option>';
					}
				$htmlContent .= '</select>';

			$htmlContent .= '</div>';
		}
	}else{
		$htmlContent .= $GetEmailApprovalList['ErrorDetail']['ErrorMessage'];
	}
	
	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['htmlContent'] = $htmlContent;
	
	echo json_encode($returnArray);
	die();
}

add_action('wp_ajax_nopriv_wp_ssl_check_dns', 'wp_ssl_check_dns');
add_action('wp_ajax_wp_ssl_check_dns', 'wp_ssl_check_dns');
function wp_ssl_check_dns(){
	$pin = isset($_POST['pin']) ? $_POST['pin'] : '';
	$errorMSG = '';
	$statusCode = 0;

	$ValidateLicenseKeyResponse = ValidateLicenseKey($pin);
	if($ValidateLicenseKeyResponse['StatusCode'] == 0){
		$DNSRecordType = $ValidateLicenseKeyResponse['DCVInfo']['DNSRecordType'];
		$DNSHostName = $ValidateLicenseKeyResponse['DCVInfo']['DNSHostName'];
		$DNSValue = $ValidateLicenseKeyResponse['DCVInfo']['DNSValue'];
		
		if($DNSRecordType == 'CNAME'){
			$dnsCheckArray = dns_get_record($DNSHostName, DNS_CNAME);
			if(!empty($dnsCheckArray)){
				foreach($dnsCheckArray as $dnsItem){
					if($DNSRecordType == 'CNAME'){
						$target = $dnsItem['target'];
					}else if($DNSRecordType == 'TXT'){
						$target = $dnsItem['txt'];
					}	

					if(strtolower($DNSValue) == strtolower($target)){
						$statusCode = 1;
					}
				}
			}
		}else if($DNSRecordType == 'TXT'){
			$DNSHostName = ltrim($ValidateLicenseKeyResponse['DomainName'],'*.');
			$dnsCheckArray = dns_get_record($DNSHostName, DNS_TXT);

			if(!empty($dnsCheckArray)){
				foreach($dnsCheckArray as $dnsItem){
					if($DNSRecordType == 'CNAME'){
						$target = $dnsItem['target'];
					}else if($DNSRecordType == 'TXT'){
						$target = $dnsItem['txt'];
					}	

					if(strtolower($DNSValue) == strtolower($target)){
						$statusCode = 1;
					}
				}
			}

			if($statusCode == 0){
				$rootDomain = getRootDomainFromDomain($DNSHostName);
				$dnsCheckArray = dns_get_record($rootDomain, DNS_TXT);
				if(!empty($dnsCheckArray)){
					foreach($dnsCheckArray as $dnsItem){
						if($DNSRecordType == 'CNAME'){
							$target = $dnsItem['target'];
						}else if($DNSRecordType == 'TXT'){
							$target = $dnsItem['txt'];
						}	

						if(strtolower($DNSValue) == strtolower($target)){
							$statusCode = 1;
						}
					}
				}
			}
		}

		if($statusCode == 0){
			$errorMSG = 'DNS not propogate.';
		}
	}else{
		$errorMSG = $ValidateLicenseKeyResponse['ErrorDetail']['ErrorMessage'];
	}

	$returnArray = array();
	$returnArray['statusCode'] = $statusCode;
	$returnArray['errorMSG'] = $errorMSG;
	echo json_encode($returnArray);
	die();
}