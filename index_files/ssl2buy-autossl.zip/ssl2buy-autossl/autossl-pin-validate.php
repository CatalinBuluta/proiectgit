<div class="wrap">
	<h1 class="wp-ssl-logo"><img src="<?php echo plugins_url('images/ssl2buy-auto-ssl-logo.svg',__FILE__ ); ?>" alt="SSL2BUY Auto SSL" /></h1>
	<div class="wp-ssl-main">
		<div class="wp-ssl-left">
			<div class="wp-ssl-steps">
				<ul>
					<li class="step-item active">
						<span class="wp-ssl-steps-count"><img src="<?php echo plugins_url('images/step-1.svg',__FILE__ ); ?>" alt="License Key" /></span>
						<span class="wp-ssl-steps-name">License Key</span>
					</li>
					<li class="step-item">
						<span class="wp-ssl-steps-count"><img src="<?php echo plugins_url('images/step-2.svg',__FILE__ ); ?>" alt="cPanel Login" /></span>
						<span class="wp-ssl-steps-name">cPanel Login</span>
					</li>
					<li class="step-item">
						<span class="wp-ssl-steps-count"><img src="<?php echo plugins_url('images/step-3.svg',__FILE__ ); ?>" alt="Confirm Domain" /></span>
						<span class="wp-ssl-steps-name">Confirm Domain</span>
					</li>
					<li class="step-item">
						<span class="wp-ssl-steps-count"><img src="<?php echo plugins_url('images/step-4.svg',__FILE__ ); ?>" alt="Validation and Installation" /></span>
						<span class="wp-ssl-steps-name">Validation and Installation</span>
					</li>
				</ul>
			</div>
			<div id="add-license-key" class="wp-ssl-left-block">
				<div class="loader" style="display: none;">
					<img src="<?php echo plugins_url('images/loager.gif',__FILE__ ); ?>" alt="Loading..." />
				</div>

				<div id="div-add-lkey">
					<h2 style="margin-top: 0;">Enter Licence Key</h2>
					<table width="100%;" class="login-table">
						<tr>
							<td><div class="pin-input"><input name="pin" type="text" id="configPin" class="text-input" autocomplete="off" placeholder="Enter Licence Key"></div></td>
						</tr>
						<tr>
							<td>
								<div class="bottom-button"><input type="button" name="checkPin" id="checkPin" value="Next" class="button button-primary button-large button-orange"></div>
							</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
		<div class="wp-ssl-right">
			<?php include 'autossl-sidebar.php'; ?>
		</div>
	</div>
</div>